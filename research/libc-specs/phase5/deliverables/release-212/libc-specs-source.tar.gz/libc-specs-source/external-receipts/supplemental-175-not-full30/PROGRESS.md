# shell-export-corollary-175 — DONE
CalculusShellTextExport.lean CHECKED (cp1, exit 0, 0.69 s, source 8f08cf61…, olean ff669b45…, 9 theorems
standard axioms) after root 174 full-30 replay terminal (exit 0). See REPORT.md, CHECKED-RECEIPT.json.
One compiler run in this job. Nothing accepted modified.
