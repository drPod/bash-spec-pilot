#!/bin/bash
# usage: check.sh <Module> <receipt-name>   (one compiler process, nonblocking lock, pinned binary)
JOB=/home/coder/agent-jobs/astra-research/phase5/claude-resume/shell-export-corollary-175
MOD=$1; NAME=$2
LOCK=/home/coder/.cache/bash-spec-pilot/phase3-compiler.lock
cd $JOB/project || exit 2
exec 9>"$LOCK"
if ! flock -w 5 9; then echo "LOCK-BUSY"; exit 75; fi
export LEAN_PATH=$JOB/project/.lake/build/lib/lean
export LEAN_NUM_THREADS=1 MIMALLOC_ARENA_RESERVE=65536
BIN=/home/coder/.elan/toolchains/leanprover--lean4---v4.31.0/bin/lean
OUT=$JOB/project/.lake/build/lib/lean/$MOD.olean
LOG=$JOB/receipts/$NAME.log
START=$(date +%s.%N)
timeout 60 prlimit --as=3221225472 -- $BIN -j1 -s16384 -DwarningAsError=true -DElab.async=false -o "$OUT" "$MOD.lean" > "$LOG" 2>&1
ST=$?
END=$(date +%s.%N)
flock -u 9
python3 - "$MOD" "$NAME" "$ST" "$START" "$END" "$OUT" "$LOG" "$BIN" <<'PY'
import sys,json,hashlib,os,datetime
mod,name,st,start,end,out,log,binp=sys.argv[1:]
def sha(p):
    return hashlib.sha256(open(p,'rb').read()).hexdigest() if os.path.exists(p) else None
job='/home/coder/agent-jobs/astra-research/phase5/claude-resume/shell-export-corollary-175'
rec={'module':mod,'checked_utc':datetime.datetime.utcnow().isoformat()+'Z','exit_status':int(st),
 'elapsed_seconds':float(end)-float(start),'source_sha256':sha(f'{job}/project/{mod}.lean'),
 'log_sha256':sha(log),'olean_sha256':sha(out) if int(st)==0 else None,
 'command':['timeout','60','prlimit','--as=3221225472','--',binp,'-j1','-s16384','-DwarningAsError=true','-DElab.async=false','-o',out,f'{mod}.lean'],
 'env':{'LEAN_PATH':f'{job}/project/.lake/build/lib/lean','LEAN_NUM_THREADS':'1','MIMALLOC_ARENA_RESERVE':'65536'}}
if int(st)!=0 and os.path.exists(out):
    os.remove(out); rec['note']='olean removed after nonzero exit'
json.dump(rec,open(f'{job}/receipts/{name}.json','w'),indent=1)
print(json.dumps({k:rec[k] for k in ('module','exit_status','elapsed_seconds','source_sha256','olean_sha256')}))
PY
exit $ST
