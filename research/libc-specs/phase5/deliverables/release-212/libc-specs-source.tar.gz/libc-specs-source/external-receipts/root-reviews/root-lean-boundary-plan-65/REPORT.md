# Lean-final boundary: source-only implementation recommendation

The next faithful implementation is a small Lean port of the **existing Coq protocol relation**, with a proved exact refinement into the accepted schedule-consuming Lean executor and its shell composition. It would replace today's empirical Coq-protocol/Lean-model alignment with a checked *intra-Lean* relation-to-executor theorem. It is not a Coq theorem import, and cannot alone certify actual Clight executions in Lean. Do not close the full Lean-final requirement on this implementation alone.

## What the authoritative sources actually require

- `research/libc-specs/phase4/DECISION.md:6`: “Do not build a general C semantics or frontend in Lean.”
- Same file, lines94–97: “No automatic checked import into Lean has been established.” “Preserve the existing Lean reference/proofs and record the requested Lean-final-checker connection as unresolved; do not silently declare that requirement satisfied or discarded.” “A Lean theorem assuming a utility simulation remains conditional on that assumption.”
- Same file, lines100–103: backend-native composition is an architectural option, not an approved replacement; “A certified cross-assistant bridge is a separate project and is not the default near-term implementation.”
- `/home/coder/agent-jobs/astra-research/phase5/entry-NEXT.md` repeats preservation of the original Lean-final-checker requirement, absence of an established automatic bridge, and honest disclosure of conditional assumptions. It contains **no precise final Lean theorem signature**.
- `integration/PROOF-CHAIN.md:35–43` explicitly recommends statement-level alignment for the headline: two checked proofs of the same first-order delivered/unread/pending/status specification. It correctly says this is not model equivalence. Lines63–67 describe the accepted paper sentence as Lean-kernel checked, while line80 describes Lean-final as joining two kernels through **trusted alignment**.

Thus these sources require preserving the Lean-final property but do not uniquely decide whether the final paper may retain a disclosed trusted *representation alignment* between Coq and Lean. The later ledger phrase “checked kernel bridge required” is stronger than these passages alone justify. Conversely a conditional `H_sim` theorem is expressly insufficient to call the requirement resolved. No exact user-approved headline sentence was found in the requested sources. Root should keep that distinction explicit rather than invent a general importer requirement or claim that a Lean protocol port proves Coq syntax.

## Concrete source anchors and mismatch to fix

`relay/Protocol.v` defines world = unread/delivered/read/write schedules plus cumulative call counters. `valid_world` restricts reads to -1 or positive and writes to >=-1. `read32` consumes one schedule entry even on error/EOF; `write_block` likewise consumes one write entry. Bytes are CompCert bytes; offsets and quotas are Coq Z, with bounded prefix/suffix.

`relay/Reach.v:16–51` defines seven `reaches` constructors (initial, read-data/error/EOF, write-data/error, drained), and `outcome := reaches initial (Halt status pending) final`.

`relay/adequacy/universal/UniversalShell.v:29` `relay_exit_shell_universal` proves, in Coq, existence of an initial Clight state/bound/status/final/pending, exact shell-call and parsed `relay && mark` execution, and universal properties of *every* permitted dry_steps execution including its exact exit status and final world. No Lean declaration denotes `dry_steps`, initial Clight memory, or this theorem's Coq proof term.

`integration/lean-final/StatefulFinal.lean` uses actual BufferRelay.runDetailed, has structural residual-schedule proofs, and composes direct/redirect/mark. But WState omits pending-loss accumulation and cumulative call counters. Its current shell witnesses and query lemmas are independently checked reference results. A bridge that forgets pending/lost or resets schedules would fail to match UniversalShell's sentence. The source header explicitly disclaims a mechanized Coq-to-Lean bridge.

## Proposed bounded theorem API (new declarations; not existing checked signatures)

Create a small `ProtocolContract.lean` port containing `World`, `Phase`, `Reaches`, `Outcome`, `ValidWorld`, and a first-order observation record. Use UInt8 for byte values and Int for quota/offset arithmetic; keep explicit representation documentation. This is a port of the existing protocol, **not new C semantics**.

The core theorem must quantify all valid worlds and preserve *every field*, not just stdout:

```lean
-- World fields mirror RelayProtocol.world, including counters.
-- execWorld uses ScheduleConsumption.executeI, adds prior delivered bytes
-- and counters, and returns the pending/lost suffix explicitly.
theorem outcome_iff_execute (w : ProtocolContract.World)
    (hv : ProtocolContract.ValidWorld w) (rc : Int)
    (z : ProtocolContract.World) (pending : List UInt8) :
    ProtocolContract.Outcome w rc z pending ↔
      execWorld w = (rc, z, pending)
```

An extended shell state must preserve `world` and accumulated `lost`. Its contract primitive uses `Outcome`, rather than assuming a simulation theorem; its executable primitive uses execWorld. Then prove without any assumed `H_sim`:

```lean
theorem shell_contract_iff_execute
    (cmd : ShellObservation.Command ContractAtom)
    (s t : ContractShellState) (rc : Nat)
    (hv : ProtocolContract.ValidWorld s.world) :
    ShellObservation.Exec contractPrim cmd s rc t ↔
      ShellObservation.Exec executablePrim cmd s rc t
```

The immediate headline instance should exactly match the *shell component* of UniversalShell: direct relay followed by conditional mark, all valid initial worlds and accumulated lost suffixes, return status retained, failed relay does not mark, success appends bang, and residual schedules/world plus pending-loss preserved. Reuse `ShellObservation.command_refines` for each direction; prove valid-world preservation to thread its invariant. Attach a query corollary via existing `query_transfer`. This general theorem covers the original sequencing/conditional minimum; existing fd/pipe/redirect proofs remain separate bounded obligations and must not be claimed from this API.

## Dependencies and acceptance checks

1. Faithful protocol definitions: byte representation, Z/Int and Zlength/Nat conversions, prefix/suffix bounds, read-zero totalization, default quotas, negative-return normalization, call-count offsets, residual schedule tails.
2. Drain and outer-loop soundness for all valid worlds; completeness via outcome determinism or inversion of the seven constructors. Termination is a real obligation, not a supplied fuel-success premise.
3. Show instrumented execution projection and actual residuals using accepted ScheduleConsumption. Account explicitly for pending suffix on failed write and accumulating lost at process exit.
4. General valid-world preservation and shell composition proof. Include success/read-error/write-zero/write-error and failure-then-recovery witnesses as discriminating checks, not as replacements for the universal theorem.
5. Exact matching Coq corollary should expose the same observation tuple from `relay_exit_shell_universal` (status/unread/delivered/pending/reads/writes/counters). Both sides' assumptions printed, definition/source identities frozen.
6. Root audit must label the remaining Coq-to-Lean representation correspondence honestly. Comparing generated JSON or checking source hashes is identity evidence, not proof translation.

If the accepted final sentence explicitly says **Lean checks that the generated Clight program satisfies the shell query**, these steps still leave that source claim open. Closing it requires a particular checked proof representation/export route covering the relevant Coq derivation, or another concrete source-certified connection; neither is already supplied by current artifacts. Do not introduce `axiom coq_sound` or an opaque imported proposition and call it complete. The sources explicitly counsel against launching an indiscriminate general importer project. Root should review the exact headline/trust-boundary choice before undertaking that substantially different implementation.

No compilers, network, model CLIs, services, or repo edits used in this task.
