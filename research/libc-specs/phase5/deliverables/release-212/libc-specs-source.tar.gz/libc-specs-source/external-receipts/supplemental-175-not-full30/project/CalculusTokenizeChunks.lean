import CalculusTokenize
open CalculusNested CalculusExport CalculusBody CalculusRelayOuter CalculusTokenize

/-!
# CalculusTokenizeChunks: kernel-checked TEXT → tokens → AST for the three full exports
# (calculus-correspondence-18, 2026-09-08)

`decide +kernel` on `tokenizeTotal` over a whole 1,300-character export does not finish (-15,
measured >900 s), but chunks of ≤ 230 characters do. Each export text is split at ASCII spaces
(all outside string literals), every chunk's tokenization is kernel-evaluated, the split
itself is kernel-checked as a string equality, and the pieces are glued by the proved
`tokenizeTotal_concat_space`. The result: `*_text_tokens` and `*_text_parse` are kernel-checked
statements about the VERBATIM exporter text (`writeBlockText`/`relayText`/`readBlockText`),
with no executable link left. -/

namespace CalculusTokenizeChunks

def wb_c0 : String := "(seq (assign b (fst ι)) (seq (assign off (range:0:4611686018427387903 (fst (snd ι)))) (seq (assign n (range:0:4611686018427387903 (snd (snd ι)))) (seq (if (<= (pair off n)) pass (raise (pair \"AssertionFailure\" ()))) (seq (seq"
def wb_t0 : List String := ["(", "seq", "(", "assign", "b", "(", "fst", "ι", ")", ")", "(", "seq", "(", "assign", "off", "(", "range:0:4611686018427387903", "(", "fst", "(", "snd", "ι", ")", ")", ")", ")", "(", "seq", "(", "assign", "n", "(", "range:0:4611686018427387903", "(", "snd", "(", "snd", "ι", ")", ")", ")", ")", "(", "seq", "(", "if", "(", "<=", "(", "pair", "off", "n", ")", ")", "pass", "(", "raise", "(", "pair", "\"AssertionFailure\"", "(", ")", ")", ")", ")", "(", "seq", "(", "seq"]
set_option maxRecDepth 100000 in
theorem wb_tok0 : tokenizeTotal wb_c0 = some wb_t0 := by decide +kernel

def wb_c1 : String := "(get $t9 b len) (if (<= (pair n $t9)) pass (raise (pair \"AssertionFailure\" ())))) (seq (seq (get $t10 b len) (assign l $t10)) (seq (seq (get $t11 b cap) (if (<= (pair l $t11)) pass (raise (pair \"AssertionFailure\" ())))) (seq (seq"
def wb_t1 : List String := ["(", "get", "$t9", "b", "len", ")", "(", "if", "(", "<=", "(", "pair", "n", "$t9", ")", ")", "pass", "(", "raise", "(", "pair", "\"AssertionFailure\"", "(", ")", ")", ")", ")", ")", "(", "seq", "(", "seq", "(", "get", "$t10", "b", "len", ")", "(", "assign", "l", "$t10", ")", ")", "(", "seq", "(", "seq", "(", "get", "$t11", "b", "cap", ")", "(", "if", "(", "<=", "(", "pair", "l", "$t11", ")", ")", "pass", "(", "raise", "(", "pair", "\"AssertionFailure\"", "(", ")", ")", ")", ")", ")", "(", "seq", "(", "seq"]
set_option maxRecDepth 100000 in
theorem wb_tok1 : tokenizeTotal wb_c1 = some wb_t1 := by decide +kernel

def wb_c2 : String := "(get $t12 b bytes) (assign req (slice (pair $t12 (pair off n))))) (seq (seq (get $t13 σ writes) (assign q (head_or (pair $t13 (length (range-list:0:255 req)))))) (seq (seq (get $t14 σ writes) (set-attr σ writes (tail $t14))) (seq"
def wb_t2 : List String := ["(", "get", "$t12", "b", "bytes", ")", "(", "assign", "req", "(", "slice", "(", "pair", "$t12", "(", "pair", "off", "n", ")", ")", ")", ")", ")", "(", "seq", "(", "seq", "(", "get", "$t13", "σ", "writes", ")", "(", "assign", "q", "(", "head_or", "(", "pair", "$t13", "(", "length", "(", "range-list:0:255", "req", ")", ")", ")", ")", ")", ")", "(", "seq", "(", "seq", "(", "get", "$t14", "σ", "writes", ")", "(", "set-attr", "σ", "writes", "(", "tail", "$t14", ")", ")", ")", "(", "seq"]
set_option maxRecDepth 100000 in
theorem wb_tok2 : tokenizeTotal wb_c2 = some wb_t2 := by decide +kernel

def wb_c3 : String := "(seq (get $t15 σ write_calls) (set-attr σ write_calls (+ (pair $t15 1)))) (seq (if (< (pair q 0)) (return -1) pass) (seq (assign k (min (pair q (length (range-list:0:255 req))))) (seq (seq (get $t16 σ delivered) (set-attr σ"
def wb_t3 : List String := ["(", "seq", "(", "get", "$t15", "σ", "write_calls", ")", "(", "set-attr", "σ", "write_calls", "(", "+", "(", "pair", "$t15", "1", ")", ")", ")", ")", "(", "seq", "(", "if", "(", "<", "(", "pair", "q", "0", ")", ")", "(", "return", "-1", ")", "pass", ")", "(", "seq", "(", "assign", "k", "(", "min", "(", "pair", "q", "(", "length", "(", "range-list:0:255", "req", ")", ")", ")", ")", ")", "(", "seq", "(", "seq", "(", "get", "$t16", "σ", "delivered", ")", "(", "set-attr", "σ"]
set_option maxRecDepth 100000 in
theorem wb_tok3 : tokenizeTotal wb_c3 = some wb_t3 := by decide +kernel

def wb_c4 : String := "delivered (append (pair $t16 (take (pair (range-list:0:255 req) (range:0:4611686018427387903 k))))))) (return k)))))))))))))))"
def wb_t4 : List String := ["delivered", "(", "append", "(", "pair", "$t16", "(", "take", "(", "pair", "(", "range-list:0:255", "req", ")", "(", "range:0:4611686018427387903", "k", ")", ")", ")", ")", ")", ")", ")", "(", "return", "k", ")", ")", ")", ")", ")", ")", ")", ")", ")", ")", ")", ")", ")", ")", ")"]
set_option maxRecDepth 100000 in
theorem wb_tok4 : tokenizeTotal wb_c4 = some wb_t4 := by decide +kernel

set_option maxRecDepth 100000 in
theorem wb_text_split : writeBlockText = ((((wb_c0 ++ " " ++ wb_c1) ++ " " ++ wb_c2) ++ " " ++ wb_c3) ++ " " ++ wb_c4) := by decide +kernel

set_option maxRecDepth 100000 in
theorem wb_toks_split : writeBlockToks = ((((wb_t0 ++ wb_t1) ++ wb_t2) ++ wb_t3) ++ wb_t4) := by decide +kernel

theorem writeBlock_text_tokens : tokenizeTotal writeBlockText = some writeBlockToks := by
  rw [wb_text_split, wb_toks_split]
  have h := wb_tok0
  have h := tokenizeTotal_concat_space _ _ _ _ h wb_tok1
  have h := tokenizeTotal_concat_space _ _ _ _ h wb_tok2
  have h := tokenizeTotal_concat_space _ _ _ _ h wb_tok3
  have h := tokenizeTotal_concat_space _ _ _ _ h wb_tok4
  exact h

theorem writeBlock_text_parse : parseText writeBlockText = some writeBlockBody := by
  simp only [parseText, writeBlock_text_tokens, writeBlock_parse]

def rl_c0 : String := "(seq (remove-elem σ block 0) (seq (add-elem σ block 0) (seq (assign b (elem σ block 0)) (seq (set-attr b cap 32) (seq (set-attr b len 0) (seq (set-attr b bytes (empty ())) (while true (seq (seq (seq (action $t17 read_block b)"
def rl_t0 : List String := ["(", "seq", "(", "remove-elem", "σ", "block", "0", ")", "(", "seq", "(", "add-elem", "σ", "block", "0", ")", "(", "seq", "(", "assign", "b", "(", "elem", "σ", "block", "0", ")", ")", "(", "seq", "(", "set-attr", "b", "cap", "32", ")", "(", "seq", "(", "set-attr", "b", "len", "0", ")", "(", "seq", "(", "set-attr", "b", "bytes", "(", "empty", "(", ")", ")", ")", "(", "while", "true", "(", "seq", "(", "seq", "(", "seq", "(", "action", "$t17", "read_block", "b", ")"]
set_option maxRecDepth 100000 in
theorem rl_tok0 : tokenizeTotal rl_c0 = some rl_t0 := by decide +kernel

def rl_c1 : String := "(assign r $t17)) (seq (if (< (pair r 0)) (return 1) pass) (seq (if (== (pair r 0)) (return 0) pass) (seq (assign off 0) (while (< (pair off r)) (seq (seq (seq (action $t18 write_block (pair b (pair (range:0:4611686018427387903"
def rl_t1 : List String := ["(", "assign", "r", "$t17", ")", ")", "(", "seq", "(", "if", "(", "<", "(", "pair", "r", "0", ")", ")", "(", "return", "1", ")", "pass", ")", "(", "seq", "(", "if", "(", "==", "(", "pair", "r", "0", ")", ")", "(", "return", "0", ")", "pass", ")", "(", "seq", "(", "assign", "off", "0", ")", "(", "while", "(", "<", "(", "pair", "off", "r", ")", ")", "(", "seq", "(", "seq", "(", "seq", "(", "action", "$t18", "write_block", "(", "pair", "b", "(", "pair", "(", "range:0:4611686018427387903"]
set_option maxRecDepth 100000 in
theorem rl_tok1 : tokenizeTotal rl_c1 = some rl_t1 := by decide +kernel

def rl_c2 : String := "off) (range:0:4611686018427387903 r)))) (assign w $t18)) (seq (if (<= (pair w 0)) (seq (seq (get $t19 σ lost) (seq (get $t20 b bytes) (set-attr σ lost (append (pair $t19 (slice (pair $t20 (pair (range:0:4611686018427387903 off)"
def rl_t2 : List String := ["off", ")", "(", "range:0:4611686018427387903", "r", ")", ")", ")", ")", "(", "assign", "w", "$t18", ")", ")", "(", "seq", "(", "if", "(", "<=", "(", "pair", "w", "0", ")", ")", "(", "seq", "(", "seq", "(", "get", "$t19", "σ", "lost", ")", "(", "seq", "(", "get", "$t20", "b", "bytes", ")", "(", "set-attr", "σ", "lost", "(", "append", "(", "pair", "$t19", "(", "slice", "(", "pair", "$t20", "(", "pair", "(", "range:0:4611686018427387903", "off", ")"]
set_option maxRecDepth 100000 in
theorem rl_tok2 : tokenizeTotal rl_c2 = some rl_t2 := by decide +kernel

def rl_c3 : String := "(range:0:4611686018427387903 r))))))))) (return 2)) pass) (assign off (+ (pair off w))))) pass)))))) pass))))))))"
def rl_t3 : List String := ["(", "range:0:4611686018427387903", "r", ")", ")", ")", ")", ")", ")", ")", ")", ")", "(", "return", "2", ")", ")", "pass", ")", "(", "assign", "off", "(", "+", "(", "pair", "off", "w", ")", ")", ")", ")", ")", "pass", ")", ")", ")", ")", ")", ")", "pass", ")", ")", ")", ")", ")", ")", ")", ")"]
set_option maxRecDepth 100000 in
theorem rl_tok3 : tokenizeTotal rl_c3 = some rl_t3 := by decide +kernel

set_option maxRecDepth 100000 in
theorem rl_text_split : relayText = (((rl_c0 ++ " " ++ rl_c1) ++ " " ++ rl_c2) ++ " " ++ rl_c3) := by decide +kernel

set_option maxRecDepth 100000 in
theorem rl_toks_split : relayToks = (((rl_t0 ++ rl_t1) ++ rl_t2) ++ rl_t3) := by decide +kernel

theorem relay_text_tokens : tokenizeTotal relayText = some relayToks := by
  rw [rl_text_split, rl_toks_split]
  have h := rl_tok0
  have h := tokenizeTotal_concat_space _ _ _ _ h rl_tok1
  have h := tokenizeTotal_concat_space _ _ _ _ h rl_tok2
  have h := tokenizeTotal_concat_space _ _ _ _ h rl_tok3
  exact h

theorem relay_text_parse : parseText relayText = some relayBody := by
  simp only [parseText, relay_text_tokens, relay_parse]

def rb_c0 : String := "(seq (assign b ι) (seq (seq (get $t1 σ reads) (seq (get $t2 b cap) (assign q (head_or (pair $t1 $t2))))) (seq (seq (get $t3 σ reads) (set-attr σ reads (tail $t3))) (seq (seq (get $t4 σ read_calls) (set-attr σ read_calls (+ (pair"
def rb_t0 : List String := ["(", "seq", "(", "assign", "b", "ι", ")", "(", "seq", "(", "seq", "(", "get", "$t1", "σ", "reads", ")", "(", "seq", "(", "get", "$t2", "b", "cap", ")", "(", "assign", "q", "(", "head_or", "(", "pair", "$t1", "$t2", ")", ")", ")", ")", ")", "(", "seq", "(", "seq", "(", "get", "$t3", "σ", "reads", ")", "(", "set-attr", "σ", "reads", "(", "tail", "$t3", ")", ")", ")", "(", "seq", "(", "seq", "(", "get", "$t4", "σ", "read_calls", ")", "(", "set-attr", "σ", "read_calls", "(", "+", "(", "pair"]
set_option maxRecDepth 100000 in
theorem rb_tok0 : tokenizeTotal rb_c0 = some rb_t0 := by decide +kernel

def rb_c1 : String := "$t4 1)))) (seq (if (< (pair q 0)) (return -1) pass) (seq (seq (get $t5 b cap) (seq (get $t6 σ input) (assign k (min (pair (max (pair 1 q)) (min (pair $t5 (length $t6)))))))) (seq (seq (get $t7 σ input) (set-attr b bytes (take"
def rb_t1 : List String := ["$t4", "1", ")", ")", ")", ")", "(", "seq", "(", "if", "(", "<", "(", "pair", "q", "0", ")", ")", "(", "return", "-1", ")", "pass", ")", "(", "seq", "(", "seq", "(", "get", "$t5", "b", "cap", ")", "(", "seq", "(", "get", "$t6", "σ", "input", ")", "(", "assign", "k", "(", "min", "(", "pair", "(", "max", "(", "pair", "1", "q", ")", ")", "(", "min", "(", "pair", "$t5", "(", "length", "$t6", ")", ")", ")", ")", ")", ")", ")", ")", "(", "seq", "(", "seq", "(", "get", "$t7", "σ", "input", ")", "(", "set-attr", "b", "bytes", "(", "take"]
set_option maxRecDepth 100000 in
theorem rb_tok1 : tokenizeTotal rb_c1 = some rb_t1 := by decide +kernel

def rb_c2 : String := "(pair $t7 (range:0:4611686018427387903 k))))) (seq (set-attr b len (range:0:4611686018427387903 k)) (seq (seq (get $t8 σ input) (set-attr σ input (drop (pair $t8 (range:0:4611686018427387903 k))))) (return k))))))))))"
def rb_t2 : List String := ["(", "pair", "$t7", "(", "range:0:4611686018427387903", "k", ")", ")", ")", ")", ")", "(", "seq", "(", "set-attr", "b", "len", "(", "range:0:4611686018427387903", "k", ")", ")", "(", "seq", "(", "seq", "(", "get", "$t8", "σ", "input", ")", "(", "set-attr", "σ", "input", "(", "drop", "(", "pair", "$t8", "(", "range:0:4611686018427387903", "k", ")", ")", ")", ")", ")", "(", "return", "k", ")", ")", ")", ")", ")", ")", ")", ")", ")", ")"]
set_option maxRecDepth 100000 in
theorem rb_tok2 : tokenizeTotal rb_c2 = some rb_t2 := by decide +kernel

set_option maxRecDepth 100000 in
theorem rb_text_split : readBlockText = ((rb_c0 ++ " " ++ rb_c1) ++ " " ++ rb_c2) := by decide +kernel

set_option maxRecDepth 100000 in
theorem rb_toks_split : readBlockToks = ((rb_t0 ++ rb_t1) ++ rb_t2) := by decide +kernel

theorem readBlock_text_tokens : tokenizeTotal readBlockText = some readBlockToks := by
  rw [rb_text_split, rb_toks_split]
  have h := rb_tok0
  have h := tokenizeTotal_concat_space _ _ _ _ h rb_tok1
  have h := tokenizeTotal_concat_space _ _ _ _ h rb_tok2
  exact h

theorem readBlock_text_parse : parseText readBlockText = some readBlockBody := by
  simp only [parseText, readBlock_text_tokens, readBlock_parse]

end CalculusTokenizeChunks
