# Supplemental 188 replay preparation

Private, reproducible staging for accepted root188 `CalculusShellTextExport`.
**Not part of full-30.** This job did not edit the research repo, manifests, or shared archives, and did not run the compiler (181 owns compiler work).

## Closure

`archive/` is a fresh copy of the **minimal transitive Lean source** needed to compile `CalculusShellTextExport` without inherited `.olean` files and without Lake.

- 20 accepted shellfrontend142 modules + toolchain/lakefile/fixtures (byte-identical to private-142 and shared `calculus-shellfrontend142`)
- `CalculusLowering.lean` (`45a2bae49592eef5eb0979c5de633b284a0ee07a31e0930dc10539c9af3197c3`)
- `CalculusQueryExportLink.lean` (`1f3265be91db5c9a692435cf1345b9eecf1919164deba235fa83805a20dbd7b1`)
- frozen module175 `CalculusShellTextExport.lean` (`8f08cf61c4f126e0b994a436f2fd7cf62dcee09b440e7268c15c454559a0c114`) matching root188 / audit185 / 175 frozen src + live source

Excluded (unverified, not imported): `CalculusShellTextNeg`, `CalculusShellTextPos`.

Full SHA256 table: `CLOSURE.json`. Identities checked against 142 pins, query-export-link receipt, lowering pin, and 175/188/185 export hash.

## Replay recipe (`replay.py`)

Isolated adapter (imports shared helpers read-only):

- stages a **new** scratch copy of `archive/`
- serial Lean **4.31.0** under the existing shared compiler lock (`run_real`, lock wait 5s, up to 60 lock-only retries)
- `timeout 60` + `prlimit --as=3221225472` (3 GiB)
- `-j1 -s16384 -DwarningAsError=true -DElab.async=false`
- env: `LEAN_NUM_THREADS=1`, `MIMALLOC_ARENA_RESERVE=65536`, `LEAN_PATH` = scratch only
- fail-closed: source hashes, empty logs, missing oleans, `#print axioms` names, whitelist `{propext, Classical.choice, Quot.sound}`
- **9** named outputs on `CalculusShellTextExport` (exact list in `CLOSURE.json`)
- no inherited oleans, no `lake` fan-out

## Validation this job

- Python syntax: `python3 -m py_compile replay.py` (pass)
- All 26 closure files hash-match `CLOSURE.json` (pass)
- Compiler **not** executed

## Root command (later, under lock, 181 paused/terminal)

From this job directory:

```
python3 replay.py
```

Limits: 3 GiB address space, 60s per module, 1 Lean thread, serial `-j1`, shared lock. Supplemental only; does not close source-to-calculus C (OPEN181). Do not change accepted bytes.
