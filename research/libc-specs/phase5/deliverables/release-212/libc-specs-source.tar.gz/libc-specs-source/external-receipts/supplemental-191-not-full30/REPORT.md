Private supplemental 188 replay is staged in this job only. Repo/manifest/archives were not edited and the compiler was not run.

**Closure:** `archive/` + `CLOSURE.json` — 23 Lean files plus fixtures/toolchain. Frozen export is `8f08cf61c4f126e0…` (175/185/188). 142 modules, Lowering `45a2bae4…`, ExportLink `1f3265be…` match accepted pins. Neg/Pos omitted.

**Recipe:** `replay.py` stages a fresh scratch tree, serial Lean 4.31 under the shared lock, 3 GiB / 60s / `-j1 -s16384` / `warningAsError` / `async=false`, `LEAN_NUM_THREADS=1`, `MIMALLOC_ARENA_RESERVE=65536`. Fail-closed on hashes, logs, oleans, and the **9** named axiom prints. No inherited oleans, no Lake.

**Checked now:** 26/26 SHA256 identities; `python3 -m py_compile replay.py`.

**Later (181 paused, under lock):** `python3 replay.py` from this job dir. Supplemental, not full-30. C-link remains OPEN181.