Readonly **cp17** audit (not 194’s cp15). 181 was not compiled or edited; resume may still be running — hashes are the frozen pin.

**Pin:** `ClightRelayLink` src `c45f1825…` = live = cp17; log `a42d76aa…`; olean `bcf9558e…`; exit 0. Thirteen `#print axioms` names: only `propext` / `Classical.choice` / `Quot.sound`.

**Link:** `fRelay_body` by `rfl`. `relay_clight_execute` is `runFunc fRelay (fuel+inp.length+46)` vs `BufferRelay.execute` on status, output, remain, both residuals, both counters, status-2 `[off,n)`. Calculus corollaries exist with exported-body identities + headroom/`Headroom`; shared path is `atomStep .relay`. No CompCert `step*`.

**187:** dump `read` is always 32, so the extra `min cnt …` formula is **unused generality**, not a hole in the theorems. Header `cast_case_l2l` is documentation. Uninit = total `UInt8` ∀`m0`; calculus glue zeros mem. Read error leaves memory unchanged. `lost` is Nested ghost; prior lost is not in C RAM.

**Verdict:** `ACCEPT_WITH_STATED_TCB`. Writeups: `AUDIT.json`, `REPORT.md`; critical notes in 181 `FROM-FINAL-AUDIT.md`.