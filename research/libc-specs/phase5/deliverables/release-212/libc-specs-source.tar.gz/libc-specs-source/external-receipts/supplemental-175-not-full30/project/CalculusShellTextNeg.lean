import CalculusShellText
open CalculusShellText
namespace CalculusShellText
theorem fixture_reject_pipe : parseSupported "relay | mark" = none := rfl
theorem fixture_reject_newline : parseSupported "relay
mark" = none := rfl
end CalculusShellText
