# 181 cp20 Clight source-link replay preparation (197-authorized)

Private staging for Claude-181 `ClightRelayLink` **cp20** with **cp18** subset and **cp19** dump.
**Not full-30. Compiler not run here** (root runs `python3 replay.py` after 181 is terminal).
Explicit authorization: `root-clight-source-review-197/ROOT-REVIEW.json` `accepted: true`.
191 supplemental was accepted at 198; user goal remains incomplete.

## Source-pin update (why not cp17)

196 originally froze **receipt/cp17** because live 181 had already moved. Root 197 then reviewed the post-187 delta and **accepted the later bytes**:

- cp18 `ClightSubset` restricts read to count 32 / reuses `readAmount`, header fix
- cp19 dump unchanged vs cp2/cp17 dump
- cp20 proof adjusts `extRead` and adds generated-body corollary + extra `#print axioms`

cp17 snapshot is preserved under `historical-cp17/` and is **not** in the live closure.

| file | sha256 | pin |
|---|---|---|
| ClightSubset.lean | `7e3061ead3041cfc4ac9ed13135921be6efa04ceeaabd1d5283792b31db95b58` | 181 `receipts/cp18-ClightSubset.src.lean` |
| RelayClightDump.lean | `fd49f46c3c414c23294e71efeebcf98fc833573d86a12bbde217630253ac497a` | 181 `receipts/cp19-RelayClightDump.src.lean` |
| ClightRelayLink.lean | `cc02a88c4ec8ddadb2344d8df77c04bebbbad8390af3d70bac4aeb3542fdc467` | 181 `receipts/cp20-ClightRelayLink.src.lean` |

197 also recorded oleans/logs (not replayed here): subset olean `4bccf47d…05aacf`, dump olean `5b257fff…9d538d`, proof olean `3d4674d8…617cca`, proof log `4fb77cff…43764d`. Independent 195 cp17-audit hash `a5c689e5…cef876`.

15 dependency `.lean` files unchanged vs cp17 closure / 142/70/87 pins (see `CLOSURE.json`).

**Generator freeze** (`freeze/gen/`): `clight_to_lean.py` `75755153…ecc5ed`, `relay.v` `ce8c381c…0ab687`, `relay.c` `c5abc06f…1afe68`.

## Exact axiom names from cp20 (computed: **18**)

Order as `#print axioms` in `ClightRelayLink.lean`:

`inner_run`, `outer_data`, `outer_run`, `drain_writes_drop`, `outer_read_error`, `outer_eof`, `read_and_set`, `inner_step_fail`, `inner_step_ok`, `inner_done`, `relay_clight_execute`, `relay_clight_execute_body`, `clight_calculus_initialState`, `clight_calculus_shared`, `fRelay_body`, `evalArgs_read`, `extRead_pos`, `extWrite_eq`

Whitelist: `{propext, Classical.choice, Quot.sound}`.

## Closure (computed 18 Lean files + toolchain)

Import graph of `ClightRelayLink` — **not** 191’s 23-file supplemental.

## Replay recipe (`replay.py`)

Isolated adapter; **local** `runner_support.py` `67b0c574322212d990d40bfb7975c65c7642afdccf0df0e9cc2073543a4279ad`.

- stages a **new** scratch copy of `archive/` (`prefix clight181-`)
- **before Lean:** regenerate dump from frozen `relay.v` + generator; byte-compare
- **before Lean:** 17 generator fixtures from 189
- serial Lean **4.31.0** under shared lock (`run_real`, lock wait 5s, up to 60 lock-only retries)
- `timeout 60` + `prlimit --as=3221225472` (3 GiB)
- `-j1 -s16384 -DwarningAsError=true -DElab.async=false`
- env: `LEAN_NUM_THREADS=1`, `MIMALLOC_ARENA_RESERVE=65536`, `LEAN_PATH` = scratch only
- fail-closed: source hashes, empty logs, missing oleans, `#print axioms` names, whitelist
- **18** named outputs on **`ClightRelayLink` only**
- no inherited oleans, no `lake`

## Validation this job (199 + 196)

- `python3 -m py_compile replay.py tests/generator_fixtures.py`
- import check of frozen `runner_support`
- all `CLOSURE.json` archive hashes
- generator fixtures executed (python only)
- compiler **not** executed

## TCB (197)

CompCert clightgen; syntax-directed Python dump; reviewed Lean Clight/Cop subset transcription; scheduled libc contracts; Lean 4.31.0 kernel; pinned C/v bytes; host prlimit/timeout/lock.

Limits: not CompCert `step*`; total byte memory not Vundef; prior lost is ghost not C RAM.

## Root command (later; 181 terminal; 191 already accepted at 198)

```
python3 replay.py
```

from this job directory. **PREPARATION only.** `goal_complete` remains false.
