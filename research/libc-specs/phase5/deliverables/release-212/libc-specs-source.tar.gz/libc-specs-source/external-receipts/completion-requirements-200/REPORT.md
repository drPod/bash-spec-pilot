# completion-requirements-audit-200 — REPORT (read-only)

Scope: requirement-by-requirement audit of the research program against the actual original
user records, the four ledger documents, the current paper (193), and the final theorem types
and root receipts. No compiler, trials, edits outside this job. Matrix with evidence per row:
`REQUIREMENT-MATRIX.json`. The research goal is not marked complete here; that is root's call.

## What was verified in this job (not taken from reports)

- The five user records ORIGINAL-USER-SCOPE.md relies on exist verbatim in the codex rollouts
  (01-14-34 lines 1243/1252/2228; 05-17-11 line 323), and the 2026-09-07T21:25Z instruction
  "okay do that now. all of it. and maybe do other case studies beyond just UTF-8?" exists at
  rollout 08-04-24 line 1915 (REQUIREMENTS.md cites it without a file; now located).
- Repo copies of the promoted modules hash-match the acceptance receipts: ClightSubset 7e3061ea…,
  RelayClightDump fd49f46c…, ClightRelayLink cc02a88c… (root197), CalculusShellTextExport
  8f08cf61… (root188/198); generator/relay.v/relay.c copies in integration/lean/source-clight
  match 75755153…/ce8c381c…/c5abc06f…; lakefile registers all four; manifest has 30 entries and
  does not include them (supplemental, as the receipts say).
- Final theorem types re-read: `relay_clight_execute(_body)` is stated on the generated function
  (`runFunc fRelay` / `exec fRelay.ret _ fRelay.body`), for every initial memory; the two
  corollaries compose the accepted 67/70 theorems and name `CalculusCommands.atomStep .relay`.
  18 printed assumptions: `fRelay_body` axiom-free, the rest propext/Classical.choice/Quot.sound.
- TCB versus claims (own inspection of the final `ClightSubset` plus reviews 187/194/195/197):
  the semantics is a transcription of exactly the Cop/Clight rules `f_relay` uses (signed
  tlong/tint compare via i2l sign extension, unsigned tulong arithmetic mod 2^64, long↔long
  identity = `cast_case_pointer` on ptr64, `Swhile` = CompCert's definition, Kloop1/Kloop2,
  `bool_val` at tint, `eval_exprlist` casts, ptr+long with sizeof tuchar=1). It is a fuel-indexed
  Option big-step, not `Clight.step*`; memory is total UInt8 with ∀ m0 (not a Vundef theorem);
  read error leaves memory unchanged; `read` accepts only the contract shape (0, p, 32) and uses
  `BufferRelay.readAmount`; `write` uses `min q cnt`; the calculus `lost` prefix is a ghost, only
  the current call's `[off,n)` is C memory. Acceptance 197 states exactly this TCB. No document
  inspected claims CompCert step preservation.

## Verdict per original requirement (details in the matrix)

Every requirement stated in the user records has a root-accepted, kernel/checker-backed result at
an explicitly documented bound: script/query Lean-final theorem over the actual calculus (U1–U2),
C-as-specification with libc-only contracts (U3), utility C compiled into the reasoning language
for the relay with the reviewed Clight-subset TCB (U4), related-work review and library reuse
(U5), the bounded UTF-8 negative calibration (U6), the head/wc case studies at body+wrapper level
(U7), and no silent scope change (U8). REQUIREMENTS.md rows R1–R11 are complete at their bounds;
R12 (paper/artifact) is pending packaging. The matrix lists no genuine remaining proof gap that
the original records mandate. It lists nine explicit trusted boundaries that must travel with
every claim and six weak points that final documents must state.

The one non-auditable item is the user's "prestigious conference / go the step beyond"
aspiration (record :1243): the paper itself says novelty is not established; that is an honest
open judgment, not a checkable requirement, and this audit does not grade it.

## Actual remaining proof gap vs pending replay/docs/package/catalog

Remaining proof gaps mandated by the original records: none identified. Boundaries that are
sometimes described as gaps but were never mandated and are correctly disclosed: CompCert step
preservation, OCaml-source proof, Coq↔Lean import, lexer grammar theorem, full Bash, GNU main,
Vundef memory theorem, second real C utility as a script atom.

Pending packaging/documentation (no new proofs):
1. Fresh replay of the 181 closure: job 196/199 is prepared and pinned to cp18/19/20 (18 axiom
   names); root has not run it (`fresh_replay_pending: true` in root197). Run it, audit, receipt.
2. Ledgers (REQUIREMENTS.md, both COMPLETION-AUDITs, PROOF-CHAIN.md; all mtime 22:04) and paper193
   still say the source-to-calculus link is OPEN / draft-not-accepted. Reconcile to root197 with
   the TCB list verbatim, and retire or label REQUIREMENTS-CROSSWALK.md. This is understatement,
   not overclaim, but it now contradicts the acceptance record.
3. Decide the artifact shape: either add supplemental 175 and 181 entries to the manifest and
   re-run the full replay, or ship them as separately replayed supplements (198 done, 199 pending)
   and say so in the paper's artifact row.
4. Source package: builder 176/178 (reviewed 182) has never produced the tar; build after the 199
   replay, verify extract+rehash, record the tar hash. research/libc-specs stays untracked in git
   by instruction; the hashed tar is the delivery.
5. Catalog counts after the above (last: root-milestones-190).

## Do not
Mark the goal complete on this audit; claim CompCert step-level preservation; describe the
Clight subset semantics as verified; describe head/wc or the mark atom as connected to the C
source in Lean; drop any of the nine boundaries from claim sentences.
