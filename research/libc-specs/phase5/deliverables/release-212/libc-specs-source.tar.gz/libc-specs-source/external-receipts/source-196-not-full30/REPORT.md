Private **181 cp20** replay is staged in this job (197-authorized pins). Repo, 181, manifests, catalog, git, and the Lean compiler were not touched.

**Final pins (ROOT-REVIEW 197):**

- `ClightSubset.lean` `7e3061ead3041cfc4ac9ed13135921be6efa04ceeaabd1d5283792b31db95b58` (cp18)
- `RelayClightDump.lean` `fd49f46c3c414c23294e71efeebcf98fc833573d86a12bbde217630253ac497a` (cp19 = prior dump)
- `ClightRelayLink.lean` `cc02a88c4ec8ddadb2344d8df77c04bebbbad8390af3d70bac4aeb3542fdc467` (cp20)

**Why the source update:** 196 first froze cp17 because live 181 had diverged. 197 reviewed 187 fixes + literal-body corollary / extra axiom prints and accepted cp18/19/20. Old cp17 archive+docs sit in `historical-cp17/` and are not in the live closure.

**Axioms:** 18 named `#print axioms` on `ClightRelayLink` (computed from cp20): `inner_run`, `outer_data`, `outer_run`, `drain_writes_drop`, `outer_read_error`, `outer_eof`, `read_and_set`, `inner_step_fail`, `inner_step_ok`, `inner_done`, `relay_clight_execute`, `relay_clight_execute_body`, `clight_calculus_initialState`, `clight_calculus_shared`, `fRelay_body`, `evalArgs_read`, `extRead_pos`, `extWrite_eq`. Whitelist `{propext, Classical.choice, Quot.sound}`.

**TCB:** CompCert clightgen; syntax-directed Python dump; reviewed Lean Clight/Cop subset; scheduled libc contracts; Lean 4.31.0; pinned `relay.c`/`relay.v`; host lock/prlimit. Limits: no `step*`; total bytes not Vundef; prior lost is ghost.

**Closure:** 18 Lean files + toolchain. Generator `75755153…` / `relay.v` `ce8c381c…` / `relay.c` `c5abc06f…`. runner_support `67b0c574…`.

**Checks:** py_compile + runner_support import + CLOSURE hash verify + 17 generator fixtures. **No Lean compile.** 195 was cp17-only; 198 accepted 191 supplemental. User goal not complete; not full-30.

Later (181 terminal, lock): `python3 replay.py` in this job dir.
