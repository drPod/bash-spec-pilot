#!/usr/bin/env python3
"""PRIVATE 181 cp20 ClightRelayLink replay (197-authorized pins).

Does not edit shared artifact/manifest/repo. Not part of full-30.
Does not inherit oleans; no Lake. Direct Lean 4.31 serial under shared lock.
PREPARATION: root runs this after 181 terminal; this job does not compile.
"""
from __future__ import annotations

import datetime
import hashlib
import json
import re
import shutil
import sys
import tempfile
import uuid
from pathlib import Path

JOB = Path(__file__).resolve().parent
ARCH = JOB / 'archive'
support = JOB / 'runner_support.py'
if hashlib.sha256(support.read_bytes()).hexdigest() != "67b0c574322212d990d40bfb7975c65c7642afdccf0df0e9cc2073543a4279ad":
    raise RuntimeError('frozen runner support hash mismatch')
from runner_support import (
    ALLOWED_AXIOMS, HOST_LEAN_ADDRESS_SPACE, LEAN_TOOLCHAIN,
    _parse_axiom_prints, _pinned_lean_binary, hash_verify_host, run_real, sha,
)

sys.path.insert(0, str(JOB / 'tests'))
from generator_fixtures import run_all as run_generator_fixtures, GEN, RELAY_V, DUMP as FROZEN_DUMP

CLOSURE = json.loads((JOB / 'CLOSURE.json').read_text())
MODULES = list(CLOSURE['compile_order'])
AUDIT = {'ClightRelayLink': list(CLOSURE['named_theorems'])}
SOURCE_FILES = CLOSURE['files']
FROZEN_LINK = 'cc02a88c4ec8ddadb2344d8df77c04bebbbad8390af3d70bac4aeb3542fdc467'
FROZEN_DUMP_HASH = 'fd49f46c3c414c23294e71efeebcf98fc833573d86a12bbde217630253ac497a'
FROZEN_SUBSET = '7e3061ead3041cfc4ac9ed13135921be6efa04ceeaabd1d5283792b31db95b58'
GEN_HASH = '75755153f30b7f8e8045c791582ae3b7027ccb8a4743017f6815010147ecc5ed'
RELAY_V_HASH = 'ce8c381c0027a227102e47605c274d8711e72fbf8d3c75d261d1e456fc0ab687'
RELAY_C_HASH = 'c5abc06f53474d90ff7927aa485a03316e267fe758593a411f70a6d22f1afe68'
LEAN = '/home/coder/.elan/toolchains/leanprover--lean4---v4.31.0/bin/lean'
SORRY_RE = re.compile(r'\bsorry\b')


def fail(result, receipts, reason, code=1):
    result['reason'] = reason
    result['passed'] = False
    result['exit_status'] = code
    (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'passed': False, 'reason': reason}, indent=2))
    return code


def main() -> int:
    out_root = JOB / 'replay-out'
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    receipts = out_root / stamp
    receipts.mkdir(parents=True)
    result = dict(
        passed=False,
        id='lean_clight_relay_link181_cp20_replay',
        supplemental=True,
        included_in_full30=False,
        preparation_replay=True,
        per_file=[],
        axiom_results={},
        axiom_results_by_file={},
        stamp=stamp,
        receipts_dir=str(receipts),
    )
    hashes = dict(SOURCE_FILES)
    ok, identity = hash_verify_host(ARCH, hashes)
    result['file_identity'] = identity
    if not ok:
        return fail(result, receipts, 'archive identity mismatch')
    if hashes['ClightRelayLink.lean'] != FROZEN_LINK:
        return fail(result, receipts, 'cp20 ClightRelayLink source hash mismatch; not silently repinned')
    if hashes['RelayClightDump.lean'] != FROZEN_DUMP_HASH:
        return fail(result, receipts, 'cp2 dump hash mismatch; not silently repinned')
    if hashes['ClightSubset.lean'] != FROZEN_SUBSET:
        return fail(result, receipts, 'cp18 ClightSubset hash mismatch; not silently repinned')
    if sha(GEN) != GEN_HASH or sha(RELAY_V) != RELAY_V_HASH:
        return fail(result, receipts, 'frozen generator/relay.v hash mismatch')
    if sha(JOB / 'freeze/gen/relay.c') != RELAY_C_HASH:
        return fail(result, receipts, 'frozen relay.c hash mismatch')
    if (ARCH / 'lean-toolchain').read_text() != LEAN_TOOLCHAIN:
        return fail(result, receipts, 'unexpected pinned Lean toolchain')
    for module, expected in AUDIT.items():
        names = re.findall(r'^#print axioms (\S+)', (ARCH / (module + '.lean')).read_text(), re.M)
        if names != expected:
            result['audit_names'] = names
            return fail(result, receipts, 'archive audit mismatch: ' + module)
    if len(AUDIT['ClightRelayLink']) != 18:
        return fail(result, receipts, 'expected 18 named axiom outputs')
    for lean_file in ARCH.glob('*.lean'):
        body = lean_file.read_text()
        stripped = re.sub(r'/-.*?-/', '', body, flags=re.S)
        stripped = re.sub(r'--.*', '', stripped)
        if SORRY_RE.search(stripped):
            return fail(result, receipts, 'sorry present: ' + lean_file.name)
    # Recompute dump from frozen relay.v using frozen generator; byte-compare before Lean.
    regen = receipts / 'regen-RelayClightDump.lean'
    if regen.exists():
        regen.unlink()
    import subprocess
    g = subprocess.run([sys.executable, str(GEN), str(RELAY_V), str(regen)], capture_output=True, text=True)
    result['generator_regen'] = dict(
        exit_status=g.returncode, stdout=g.stdout, stderr=g.stderr,
        regen_sha256=sha(regen) if regen.is_file() else None,
        frozen_dump_sha256=FROZEN_DUMP_HASH,
        workdir=str(receipts),
        command=[sys.executable, str(GEN), str(RELAY_V), str(regen)],
    )
    if g.returncode != 0 or not regen.is_file() or sha(regen) != FROZEN_DUMP_HASH:
        return fail(result, receipts, 'regenerated dump does not byte-match frozen RelayClightDump')
    if regen.read_bytes() != (ARCH / 'RelayClightDump.lean').read_bytes():
        return fail(result, receipts, 'regenerated dump bytes != archive dump')
    # 17 negative/positive generator fixtures from 189 (python only).
    fix = receipts / 'generator-fixtures'
    audit = run_generator_fixtures(fix)
    (receipts / 'generator-fixtures.json').write_text(json.dumps(audit, indent=2) + '\n')
    result['generator_fixtures'] = dict(pass_=audit['pass'], n_cases=audit['n_cases'], n_pass=audit['n_pass'])
    if not audit['pass'] or audit['n_cases'] != 17:
        return fail(result, receipts, 'generator fixture tests failed')
    lean = _pinned_lean_binary()
    if str(lean) != LEAN:
        return fail(result, receipts, 'unexpected lean binary: ' + str(lean))
    scratch = Path(tempfile.mkdtemp(prefix='clight181-' + uuid.uuid4().hex[:8] + '-'))
    for filename in hashes:
        shutil.copy2(ARCH / filename, scratch / filename)
    staged_ok, staged_identity = hash_verify_host(scratch, hashes)
    result.update(
        scratch_prefix='clight181-', scratch=str(scratch),
        staged_identity=staged_identity,
        compiler=str(lean),
        compiler_sha256=sha(lean),
        address_space_bytes=HOST_LEAN_ADDRESS_SPACE,
    )
    if not staged_ok:
        return fail(result, receipts, 'staged snapshot identity mismatch')
    env = {'LEAN_PATH': str(scratch), 'LEAN_NUM_THREADS': '1', 'MIMALLOC_ARENA_RESERVE': '65536'}
    for module in MODULES:
        output = scratch / (module + '.olean')
        log = receipts / ('lean_clight_relay_link181_cp20_replay.' + module + '.log')
        argv = [
            'timeout', '60', 'prlimit', f'--as={HOST_LEAN_ADDRESS_SPACE}', '--',
            str(lean), '-j1', '-s16384', '-DwarningAsError=true', '-DElab.async=false',
            '-o', str(output), module + '.lean',
        ]
        lock_attempts = []
        for lock_attempt in range(60):
            code, elapsed = run_real(argv, scratch, 60, log, max_wait=5, extra_env=env)
            if not (code is None and log.exists() and 'lock wait expired' in log.read_text()):
                break
            wait_log = log.with_name(log.name + '.lock-' + str(lock_attempt))
            shutil.copy2(log, wait_log)
            lock_attempts.append(dict(attempt=lock_attempt, log=wait_log.name, log_sha256=sha(wait_log)))
        if lock_attempts:
            result.setdefault('lock_only_retries', {})[module] = lock_attempts
        if code is None and log.exists() and 'lock wait expired' in log.read_text():
            result['skipped'] = True
            return fail(result, receipts, 'compiler lock busy', code=75)
        log_text = log.read_text() if log.exists() else ''
        receipt = dict(
            file=module + '.lean', command=argv, workdir=str(scratch),
            environment={
                'LEAN_PATH': str(scratch),
                'LEAN_NUM_THREADS': '1',
                'MIMALLOC_ARENA_RESERVE': '65536',
            },
            address_space_bytes=HOST_LEAN_ADDRESS_SPACE, exit_status=code,
            elapsed_seconds=elapsed, log=str(log),
            log_sha256=sha(log) if log.exists() else None,
            output=str(output),
            output_sha256=sha(output) if output.is_file() else None,
            source_sha256=sha(scratch / (module + '.lean')),
        )
        if module == 'ClightRelayLink' and receipt['source_sha256'] != FROZEN_LINK:
            return fail(result, receipts, 'link sourcehash mismatch vs frozen cp20')
        receipt_path = receipts / ('lean_clight_relay_link181_cp20_replay.' + module + '.json')
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        result['per_file'].append({**receipt, 'receipt': receipt_path.name})
        if code != 0 or not output.is_file() or output.stat().st_size == 0:
            return fail(result, receipts, 'compiler failure or missing output: ' + module)
        if module in AUDIT:
            if not log_text.strip():
                return fail(result, receipts, 'empty axiom log (no heuristic pass): ' + module)
            names, parsed = _parse_axiom_prints(log_text)
            expected = AUDIT[module]
            namespace = module
            qualified = [n if n.startswith(namespace + '.') else namespace + '.' + n for n in expected]
            result['axiom_results_by_file'][module] = dict(
                names=names, expected=expected, qualified=qualified, parsed=parsed)
            for name, info in parsed.items():
                result['axiom_results'][module + ':' + name] = info
            ok_names = names == expected or names == qualified
            if not ok_names or any(not parsed[n]['allowed'] for n in names):
                result['audit_names'] = names
                return fail(result, receipts, 'audit mismatch or forbidden axiom: ' + module)
            if len(names) != 18:
                return fail(result, receipts, 'expected 18 named axiom outputs')
    expected_count = sum(len(v) for v in AUDIT.values())
    result['passed'] = (
        len(result['axiom_results']) == expected_count
        and set(result['axiom_results_by_file']) == set(AUDIT)
        and all(a['allowed'] for a in result['axiom_results'].values())
    )
    if not result['passed']:
        return fail(result, receipts, result.get('reason') or 'audit key order/count mismatch')
    result['exit_status'] = 0
    result['scope'] = (
        'Private replay of 181 cp20 Clight source-to-calculus link (197 pins). '
        'PREPARATION only; not acceptance; not full-30.'
    )
    result['not_claimed'] = [
        'full-30 membership',
        'full-30 membership already listed; 197 accepted pins, compiler still pending',
        'ClightSubset == CompCert Clight',
        'generator correctness beyond 17 python fixtures',
        'host Bash semantic equivalence',
        'dependency axiom re-audit (bytes pinned accepted)',
    ]
    result['axiom_whitelist'] = sorted(ALLOWED_AXIOMS)
    result['tcb'] = CLOSURE['tcb']
    (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('passed', 'exit_status', 'stamp', 'scratch') if k in result}, indent=2))
    print('receipts', receipts.name)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
