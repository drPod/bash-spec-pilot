# Source-only candidate67

Created isolated project/CalculusRelaySchedules.lean and exact ScheduleConsumption copy. New namespace imports accepted CalculusRelaySpec and reuses relay_inner_exact, root Frame facts, prologue and executor. The copied outer induction retains two extra output fields in OuterExactSchedules; four terminal/recursive cases propagate actual executeI residual schedules. General outer theorem and fresh-state runEntry lifting preserve existing integer/fuel premises. A residuals_drop corollary exposes call-count drop laws. Four #print axioms requests await the checker.

Accepted dependency files stayed byte-identical to SOURCE-SNAPSHOT.json; concurrently owned CalculusTyping.lean changed during the check, recorded in SOURCE-RECHECK.json. This worker made no repo changes. No model CLI or compiler used. Concrete UNCOMPILED candidate, not acceptance. Expected first issues: inherited record-field elaboration and executeI one-step projection simplification. No sorry/admit/new axiom or assumed simulation introduced.

Accepted outer result discards final schedules, so projection cannot recover them. Inner proof already retains writes+Frame; strengthening outer induction in a new namespace preserves accepted repo sources. After checking root may consolidate duplicated invariant or retain extension.

## Compiler result after explicit root grant

Checkpoint1 hit startup INTERNAL PANIC out of memory at0.38s under3GiBAS with elan shim. Checkpoint2 used actual Lean4.31 binary, -j1/-s16384, LEAN_NUM_THREADS=1 and MIMALLOC_ARENA_RESERVE65536 under the same3GiBAS/60s limit. Full candidate compiled in7.05s, exit0, without any source repair. All four assumption outputs contain only propext/Classical.choice/Quot.sound. SourceSHA af7e21e14e9cbbbb0ccd257f47e8b102614ad9faf778b857fe8b9aa8fe3baac4; logSHA b047524e829aabf342474331577501d45eef2d01459f4858736c837a4d4cebe0. Exact dependency source/olean hashes in DEPENDENCY-IDENTITIES.json. Lock acquired nonblocking and released after each attempt. Two of three authorized attempts used; no redundant third build. This is checker evidence awaiting root semantic/receipt review and promotion, not research completion.
