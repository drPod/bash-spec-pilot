# Codex tmux pane disappearance: confirmed OOM scope teardown

Read-only diagnosis, 2026-09-08 18:10–18:12 UTC. No tmux settings, panes, processes, services, supervision, or research files changed.

## Finding

The user systemd journal confirms repeated OOM events in tmux pane scopes. Systemd subsequently kills the surviving pane shell and processes. This is direct evidence, not a generic OOM hypothesis. At 17:09:08 the journal explicitly names bash, codex, codex-code-mode, python3 and pi victims; at 18:06:11 it names bash, codex and codex-code-mode. This explains simultaneous disappearance of the pane, Codex child agents, and tool handles. SIGKILL prevents exit-record cleanup, so missing exit.json is consistent with this evidence.

Four sequences on September 8 UTC:

| OOM detected | Pane shell SIGKILL |
|---|---|
|16:55:10|16:56:40|
|17:07:38|17:09:08|
|17:18:39|17:20:09|
|18:04:41|18:06:11|

The two scopes reporting peaks consumed 6.9G RAM + 2.1G swap and 7.0G RAM + 2.0G swap respectively. Current host has 7.8Gi RAM and 4.0Gi swap. Current memory availability is not evidence of availability during those incidents.

Current pane scope has OOMPolicy=stop, KillMode=control-group, TimeoutStopUSec=1min 30s, MemoryMax/MemoryHigh/MemorySwapMax=infinity. These present settings match the observed 90-second teardown sequence; historical exact settings were not captured. Ancestor user@1001.service memory.events has oom_kill=4. Current scopes have oom_kill=0, as expected for replacement panes. The continuing tmux server started 16:33:46, and the original other pane's Codex has run since 16:34:10. Current affected replacement pane shell started 18:08:17, Codex 18:09:01. Boot time was 16:30:52. Later failures therefore do not require a reboot or entire-window failure to explain them.

Global remain-on-exit is off; no local override was returned for the inspected replacement pane/window. A killed shell consequently disappears as a pane. This is a display consequence, not the memory failure's cause.

## Limits

Kernel journal is not visible to this user, and dmesg returns Operation not permitted. We cannot identify the first OOM-selected process or the allocation that caused memory pressure from this evidence. Do not assert that Codex itself leaked or that a particular compiler/agent caused the pressure. Global versus another ancestor memory constraint cannot be conclusively selected without kernel event details. Current pane and user ancestors inspected have unlimited memory.max; this supports host pressure as a possibility but is not a historical kernel trace. Codex log database exists, but no conversation or broad log content was dumped; confirmed external SIGKILL is sufficient to establish the pane teardown mechanism.

## Minimal proposed fix, not applied

For subsequent heavy research jobs, keep memory-heavy workers in their own systemd scopes with a deliberate memory budget and low concurrency, outside the interactive Codex pane scope. This contains worker OOM teardown and avoids carrying Codex and its shell with it. Size total budgets below available RAM, allowing host/service overhead. Simply enabling remain-on-exit would retain a dead pane for inspection but would not preserve Codex or prevent OOM. Changing pane OOMPolicy to continue alone would avoid the stop cascade but would not solve host memory exhaustion or protect against Codex itself being selected; do not present that as a complete fix.

Next evidence needed to attribute the initial memory offender: narrow privileged kernel journal around the four OOM timestamps, specifically task name/PID, constraint and memory totals. No privileged escalation attempted and no fix applied.

## Exact sanitized user journal evidence

```
2026-09-08T16:55:10+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-97496a89-59bb-436b-a4d5-bb2211398293.scope: A process of this unit has been killed by the OOM killer.
2026-09-08T16:56:40+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-97496a89-59bb-436b-a4d5-bb2211398293.scope: Stopping timed out. Killing.
2026-09-08T16:56:40+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-97496a89-59bb-436b-a4d5-bb2211398293.scope: Killing process 40792 (bash) with signal SIGKILL.
2026-09-08T16:56:40+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-97496a89-59bb-436b-a4d5-bb2211398293.scope: Failed with result 'oom-kill'.
2026-09-08T17:07:38+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: A process of this unit has been killed by the OOM killer.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Stopping timed out. Killing.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Killing process 97509 (bash) with signal SIGKILL.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Killing process 120695 (MainThread) with signal SIGKILL.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Killing process 120702 (codex) with signal SIGKILL.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Killing process 122226 (codex-code-mode) with signal SIGKILL.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Killing process 124294 (python3) with signal SIGKILL.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Killing process 124295 (python3) with signal SIGKILL.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Killing process 124296 (python3) with signal SIGKILL.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Killing process 124297 (pi) with signal SIGKILL.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Killing process 124298 (pi) with signal SIGKILL.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Killing process 124299 (pi) with signal SIGKILL.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Failed with result 'oom-kill'.
2026-09-08T17:09:08+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-fd06297e-279e-4c2e-be8d-c21febf71e78.scope: Consumed 4min 15.775s CPU time, 6.9G memory peak, 2.1G memory swap peak.
2026-09-08T17:18:39+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-c654c83f-cb96-4140-9290-323cb7007f8b.scope: A process of this unit has been killed by the OOM killer.
2026-09-08T17:20:09+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-c654c83f-cb96-4140-9290-323cb7007f8b.scope: Stopping timed out. Killing.
2026-09-08T17:20:09+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-c654c83f-cb96-4140-9290-323cb7007f8b.scope: Killing process 127103 (bash) with signal SIGKILL.
2026-09-08T17:20:09+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-c654c83f-cb96-4140-9290-323cb7007f8b.scope: Failed with result 'oom-kill'.
2026-09-08T18:04:41+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-69493bbc-83d1-4a1d-981b-f999a6fe9e24.scope: A process of this unit has been killed by the OOM killer.
2026-09-08T18:06:11+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-69493bbc-83d1-4a1d-981b-f999a6fe9e24.scope: Stopping timed out. Killing.
2026-09-08T18:06:11+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-69493bbc-83d1-4a1d-981b-f999a6fe9e24.scope: Killing process 250245 (bash) with signal SIGKILL.
2026-09-08T18:06:11+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-69493bbc-83d1-4a1d-981b-f999a6fe9e24.scope: Killing process 270443 (MainThread) with signal SIGKILL.
2026-09-08T18:06:11+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-69493bbc-83d1-4a1d-981b-f999a6fe9e24.scope: Killing process 270450 (codex) with signal SIGKILL.
2026-09-08T18:06:11+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-69493bbc-83d1-4a1d-981b-f999a6fe9e24.scope: Killing process 272647 (codex-code-mode) with signal SIGKILL.
2026-09-08T18:06:11+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-69493bbc-83d1-4a1d-981b-f999a6fe9e24.scope: Failed with result 'oom-kill'.
2026-09-08T18:06:11+00:00 vps-762c4bb6-vps-ovh-us systemd[1045]: tmux-spawn-69493bbc-83d1-4a1d-981b-f999a6fe9e24.scope: Consumed 2min 27.504s CPU time, 7.0G memory peak, 2.0G memory swap peak.
```
