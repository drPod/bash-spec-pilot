#!/usr/bin/env python3
"""189's 17 generator fixtures, bound to this job's freeze/. No Lean, no new models."""
from __future__ import annotations
import hashlib, json, re, sys, tempfile
from pathlib import Path

JOB = Path(__file__).resolve().parents[1]
GEN = JOB / "freeze/gen/clight_to_lean.py"
RELAY_V = JOB / "freeze/gen/relay.v"
DUMP = JOB / "archive/RelayClightDump.lean"
FIX = JOB / "tests/fixtures"


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run_gen(src: Path, out: Path):
    import subprocess
    r = subprocess.run([sys.executable, str(GEN), str(src), str(out)], capture_output=True, text=True)
    return r.returncode, r.stdout, r.stderr, out.read_text() if out.exists() else None


def run_all(fix_dir: Path | None = None) -> dict:
    FIX.mkdir(parents=True, exist_ok=True)
    dest = fix_dir or FIX
    dest.mkdir(parents=True, exist_ok=True)
    cases = []

    def record(name, **kw):
        cases.append({"name": name, **kw})

    frozen = DUMP.read_text()
    out1 = dest / "regen1.lean"
    out2 = dest / "regen2.lean"
    for p in (out1, out2):
        if p.exists():
            p.unlink()
    c1, o1, e1, t1 = run_gen(RELAY_V, out1)
    c2, o2, e2, t2 = run_gen(RELAY_V, out2)
    record(
        "T1_deterministic_regen_matches_frozen_dump",
        ok=c1 == 0 and c2 == 0 and t1 == t2 == frozen,
        rc=[c1, c2],
        regen_sha=sha(out1) if out1.exists() else None,
        frozen_sha=sha(DUMP),
        equal_to_frozen=t1 == frozen,
        two_runs_equal=t1 == t2,
    )

    body = frozen
    needed = [
        ".sloop", ".ssequence", ".sskip", ".scall", ".sset",
        ".sifthenelse", ".sreturn", "swhile", ".ebinop", ".econst_int",
        ".evar", ".etempvar", ".ecast", ".oadd", ".osub", ".olt", ".ole", ".oeq",
    ]
    missing = [n for n in needed if n not in body]
    body_only = body.split("body :=")[-1]
    record(
        "T2_constructor_controlflow_vs_f_relay",
        ok=not missing and body.count(".sloop") == 1 and body_only.count("swhile") == 1
        and re.findall(r"\.sreturn \(some \(\.econst_int (\d+)", body_only) == ["1", "0", "2"],
        missing=missing,
    )

    def mutate_v(tag, replacer):
        text = RELAY_V.read_text()
        m = re.search(r"Definition f_relay := \{\|(.*?)\|\}\.", text, re.S)
        assert m
        rec = m.group(1)
        new_rec = replacer(rec)
        new_text = text[: m.start(1)] + new_rec + text[m.end(1) :]
        p = dest / f"{tag}.v"
        p.write_text(new_text)
        out = dest / f"{tag}.lean"
        if out.exists():
            out.unlink()
        rc, so, se, lean = run_gen(p, out)
        return p, out, rc, so, se, lean

    p, out, rc, so, se, lean = mutate_v(
        "mut_return1to9",
        lambda rec: rec.replace(
            "Sreturn (Some (Econst_int (Int.repr 1) tint))",
            "Sreturn (Some (Econst_int (Int.repr 9) tint))",
            1,
        ),
    )
    record(
        "T3_mutate_return_code_1_to_9",
        ok=rc == 0 and lean is not None and "(.econst_int 9 .tint)" in lean,
        rc=rc, stderr=se,
    )

    p, out, rc, so, se, lean = mutate_v(
        "mut_cond_Olt_to_Ogt",
        lambda rec: rec.replace("Ebinop Olt (Etempvar _n tlong)", "Ebinop Ogt (Etempvar _n tlong)", 1),
    )
    record("T4_mutate_condition_Olt_to_unsupported_Ogt", ok=rc != 0 and lean is None, rc=rc, stderr=se.strip(), out_exists=out.exists())

    p, out, rc, so, se, lean = mutate_v(
        "mut_cond_Oeq_to_Olt",
        lambda rec: rec.replace("Ebinop Oeq (Etempvar _n tlong)", "Ebinop Olt (Etempvar _n tlong)", 1),
    )
    record(
        "T5_mutate_condition_Oeq_to_Olt_supported",
        ok=rc == 0 and lean is not None and (lean or "").count(".oeq") == 0,
        rc=rc,
    )

    p, out, rc, so, se, lean = mutate_v(
        "mut_call_arg_32_to_16",
        lambda rec: rec.replace("Econst_int (Int.repr 32) tint", "Econst_int (Int.repr 16) tint", 1),
    )
    record("T6_mutate_read_size_arg_32_to_16", ok=rc == 0 and lean is not None and ".econst_int 16" in lean, rc=rc)

    p, out, rc, so, se, lean = mutate_v(
        "mut_write_fd_1_to_3",
        lambda rec: rec.replace(
            "(Econst_int (Int.repr 1) tint) ::\n                     (Ebinop Oadd",
            "(Econst_int (Int.repr 3) tint) ::\n                     (Ebinop Oadd",
            1,
        ),
    )
    record("T7_mutate_write_fd_arg_1_to_3", ok=rc == 0 and lean is not None and ".econst_int 3 .tint" in lean, rc=rc)

    p, out, rc, so, se, lean = mutate_v(
        "mut_Sskip_to_Sswitch",
        lambda rec: rec.replace("Sskip", "Sswitch (Econst_int (Int.repr 0) tint) LSnil", 1),
    )
    record("T8_unsupported_Sswitch_rejects", ok=rc != 0 and lean is None, rc=rc, stderr=se.strip(), out_exists=out.exists())

    p, out, rc, so, se, lean = mutate_v(
        "mut_trailing_in_body",
        lambda rec: rec.replace("fn_body :=\n(Sloop", "fn_body :=\n(Sloop EXTRAJUNK", 1),
    )
    record("T9_malformed_extra_token_in_fn_body_rejects", ok=rc != 0 and lean is None, rc=rc, stderr=se.strip())

    def extra_paren(rec):
        if not rec.rstrip().endswith("Sskip)"):
            raise SystemExit("unexpected rec tail " + repr(rec[-30:]))
        return rec.rstrip() + " ExtraIdent\n"

    p, out, rc, so, se, lean = mutate_v("mut_trailing_tokens", extra_paren)
    record("T10_trailing_tokens_after_body_sexp_rejects", ok=rc != 0 and lean is None, rc=rc, stderr=se.strip())

    d = dest / "basename_trap"
    d.mkdir(exist_ok=True)
    src_trap = d / "relay.v"
    src_trap.write_text((dest / "mut_cond_Oeq_to_Olt.v").read_text())
    out_trap = d / "out.lean"
    if out_trap.exists():
        out_trap.unlink()
    rc, so, se, lean = run_gen(src_trap, out_trap)
    record(
        "T11_same_basename_relay_v_different_body_not_canned",
        ok=rc == 0 and lean is not None and lean.count(".oeq") == 0 and lean != frozen,
        rc=rc,
    )
    mut_bytes_sha = hashlib.sha256(src_trap.read_bytes()).hexdigest()
    record(
        "T12_comment_source_hash_tracks_input_bytes",
        ok=rc == 0 and lean is not None and mut_bytes_sha in lean and sha(RELAY_V) not in lean,
        input_sha=mut_bytes_sha,
    )

    gen_sha = sha(GEN)
    record(
        "T13_manifest_hash_no_self_hash_impossibility",
        ok=gen_sha in frozen and gen_sha not in GEN.read_text(),
        generator_sha256=gen_sha,
    )
    src_py = GEN.read_text()
    forbidden = ["socket", "urllib", "requests", "http", "subprocess", "os.system"]
    hits = [f for f in forbidden if f in src_py]
    record(
        "T14_read_bounds_no_network_no_subprocess",
        ok=not hits and "sys.argv" in src_py and "src.read_text" in src_py,
        forbidden_hits=hits,
    )

    p, out, rc, so, se, lean = mutate_v("mut_unknown_ident", lambda rec: rec.replace("_buf", "_evil", 1))
    record("T15_unknown_ident_rejects", ok=rc != 0 and lean is None, rc=rc, stderr=se.strip())

    p, out, rc, so, se, lean = mutate_v(
        "mut_return_none",
        lambda rec: rec.replace("Sreturn (Some (Econst_int (Int.repr 0) tint))", "Sreturn None", 1),
    )
    record("T16_Sreturn_None_reflects", ok=rc == 0 and lean is not None and "(.sreturn none)" in lean, rc=rc)

    p = dest / "nofrelay.v"
    p.write_text("Definition f_other := 1.\n")
    out = dest / "nofrelay.lean"
    if out.exists():
        out.unlink()
    rc, so, se, lean = run_gen(p, out)
    record("T17_missing_f_relay_rejects", ok=rc != 0 and lean is None, rc=rc, stderr=se.strip())

    return {
        "pass": all(c["ok"] for c in cases),
        "n_cases": len(cases),
        "n_pass": sum(1 for c in cases if c["ok"]),
        "cases": cases,
    }


if __name__ == "__main__":
    audit = run_all()
    print("PASS" if audit["pass"] else "FAIL", audit["n_pass"], "/", audit["n_cases"])
    raise SystemExit(0 if audit["pass"] else 1)
