# Ledger refresh71

Updated only REQUIREMENTS.md, COMPLETION-AUDIT.md and evaluation/DRAFT-PAPER.md current evidence rows. Read both root acceptance receipts and the original-user scope trace before editing; independently checked Calc67 promoted source/checkpoint log hashes and replay69 summary hash. Exact receipt/scope/source hashes are in SOURCE-CHECKS.json.

Calc67 now records general outer-loop and fresh-state runEntry exactness for seven fields including residual read/write schedules, under explicit actDef identities/counter headroom; arbitrary shared-state and cumulative-query work remains open. Replay69 now records eight fresh direct-Lean files,18 audits and accepted Stateful55 archive. Accounting is full19 plus six targeted additions covering25 listed entries, with no full25 claim. Historical case replay24 and prior chain counts are preserved where historical.

Original Lean script/query-over-calculus wording replaces the misleading implication that a generic Coq importer is mandatory; actual source/frontend and script/query linkage remains open. Claude61 typing/lowering and shared-state70 remain unaccepted. Local milestone64 is verified on4096; saved counts are2351 nodes/2436 edges and Atlas279 private. No compiler or network calls; no proof/manifest edits.
