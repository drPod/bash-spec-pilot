# Installed Lake concurrency source review

The installed Lean 4.31.0 Lake CLI has **no `-j`, `--jobs`, or `--threads` job-count option** in its exhaustive short/long option dispatch. No dedicated job-count environment/config setting was found in Lake CLI, Config, or Build source. Do not add a guessed flag.

`LEAN_NUM_THREADS=1` is a runtime worker-pool setting, not an explicit external-process semaphore. Lake builds schedule asynchronous tasks; module compilation launches external Lean through `rawProc` → `IO.Process.output`. The latter spawns a dedicated stdout reader, blocks on stderr/process completion, then reads the stdout task result. Lean's documented `Task.get` semantics permit temporary worker-pool expansion; dedicated tasks also run outside the regular pool. Therefore this source review does **not** establish a hard maximum of one concurrent external compiler merely from the environment setting. It also does not establish that multiple compilers necessarily overlap in the current ten-module projects.

The implemented flock serializes top-level runner invocations. The 3 GiB limit is inherited per process, not summed across a process tree. No additional invocation setting was implemented because none providing the requested guarantee was identified. A strict aggregate/concurrent-child guarantee would require a separate mechanism (for example individually scheduled direct Lean invocations), beyond pretending that this Lake flag exists. No global settings, cgroups, tmux, services, or compiler runs were touched.

Exact source files, SHA256 hashes, and line references are in LAKE-SOURCE-REVIEW.json. Existing runner checks remain valid for their stated scope; they do not test actual Lake scheduling.
