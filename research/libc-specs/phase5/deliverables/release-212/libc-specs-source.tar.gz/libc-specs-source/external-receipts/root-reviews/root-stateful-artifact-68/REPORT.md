# Stateful55 artifact registration68

Implemented a25th manifest entry lean_stateful55_replay, category current with status pending_actual_replay. Its first actual replay is NOT performed; prior full24 remains the accepted full-run scope. category current permits an explicit --only selection; no pending-category skip can silently substitute for execution.

The replay validates the exact10-file snapshot shape and SHA256 identities (eight Lean modules plus pinned toolchain and Lake file), stages and revalidates an isolated copy, locates only the installed pinned Lean binary, and compiles the explicit topological order one file at a time. No Lake, elan invocation, network or package download. Each compiler uses existing run_real shared lock,3GiB address-space cap, threads1 and local allocator override; new optional extra_env passes only isolated LEAN_PATH without global environment changes.

Every step writes a JSON receipt with exact argv/workdir/environment, source/compiler/output/log hashes, exit status and elapsed time. Missing/nonzero/empty outputs stop the chain. Final audit must report each of18 expected declarations exactly once, with only propext/Classical.choice/Quot.sound. Missing/duplicate/unexpected declarations and sorryAx/project axioms fail. Caching remains disabled.

Validation: Python syntax check and14 mocked/negative checks passed; existing timestamp tests also pass. checks.json records mock coverage. Actual compiler invocations:0. Frozen evaluation/harness untouched. Existing24 manifest entries preserved by append-only data transformation.

Next: root-granted compiler turn; invoke replay.py --fresh --only lean_stateful55_replay --out-dir <external receipt directory>. Review all8 real per-file statuses and18 audit results before any pass/full25 claim. No checked Coq/C-to-Lean bridge claimed.
