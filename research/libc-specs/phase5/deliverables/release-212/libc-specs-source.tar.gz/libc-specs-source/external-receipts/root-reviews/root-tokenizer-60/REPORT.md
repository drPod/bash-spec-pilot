# Tokenizer kernel proof investigation 60

No repository changes. Original helper SHA256 remains 5193c04525e369777dc5fbab5ae7234e199680e958e7896974ce4f6951b4f8d3.

All compiler processes terminal; no full export proof accepted. Existing compiler absence verified before initial invocation; no process was killed manually. Bounded invocations used shared flock `/home/coder/.cache/bash-spec-pilot/phase3-compiler.lock`, LEAN_NUM_THREADS=1, explicit binary lean v4.31.0, -j1 -s16384 -DElab.async=false, timeout <=180s. Initial2GiB address-space cap prevented startup. Local MIMALLOC_ARENA_RESERVE=65536 enabled startup;2GiB still failed allocation. Parent authorized3GiB cap (3221225472); retained for subsequent runs. Sampled full run RSS1.79GiB / VSZ3.15GB before bounded allocation failure.

Success: Probe.lean and First.lean compile status0. Structural literal witness `literal = String.ofList [chars]` by rfl, followed by String.length_ofList and String.toList_ofList, avoids expensive literal decoding. Pieces.lean contains ALL writeBlock single-word chunk tokenization theorems and compiles status0 under cap. Its output is pieces.log.

Failures:60-char decide,60-char rfl,60-char structural and full word-structural assemblies fail within memory cap. Full splitfix variant also failed allocation (build-splitfix.status1). Therefore no full text-to-tokens-to-AST theorem receipt or axiom audit claimed. Audit.lean ready for successful build. sourcehashes.final identifies exact experiments.
