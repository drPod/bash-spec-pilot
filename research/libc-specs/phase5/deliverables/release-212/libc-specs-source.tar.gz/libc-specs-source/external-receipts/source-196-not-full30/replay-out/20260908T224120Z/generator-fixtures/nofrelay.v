Definition f_other := 1.
