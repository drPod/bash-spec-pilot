FULL30 run `20260908T213227Z` is terminal. PID **1030693** (launcher 1030692) was observed live, polled ≤60s, and confirmed dead before the final pass. No compilers, no extra replay.

**Records:** `--fresh`, `only_filter` null, 30 IDs same order as snapshot (26 current + 3 required + 1 experimental). **29 PASS + 1 host OCaml skip.** Container OCaml `ocaml_state_based_pinned_container` PASS (exit 0, 10.89s). Clock 1266s ≈ sum wall 1266.40s.

Live `replay.py`/`manifest.json` matched snapshots during the run and after (`67b0c574…` / `8a9d4bd5…`). Cache off. Nested logs 500/500; Lean outputs 175/175; file_identity 440/440.

Tokenizer **33/1593** + **12** negatives, bins `ac158a53…`/`b64bd0ef…`. Shell **20/66/38**. Raising **16/28**. Mutant `mut_bad_byte` exit 4 is a rejection, not a positive failure. Claude175 not in this snapshot.

Root goal still open (docs / source package / catalog). Wrote `full30-receipt-audit-177/AUDIT.json`, `REPORT.md`, `NEXT.md`.