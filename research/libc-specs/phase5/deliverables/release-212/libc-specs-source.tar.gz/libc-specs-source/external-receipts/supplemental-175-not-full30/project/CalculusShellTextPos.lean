import CalculusShellText
open ShellObservation CalculusCommands CalculusShellText
namespace CalculusShellText
theorem lex_relay_and_mark :
    lexString "relay && mark" = some [Token.ident "relay", Token.andAnd, Token.ident "mark"] := rfl
theorem parse_relay_and_mark_toks :
    parseTokens [Token.ident "relay", Token.andAnd, Token.ident "mark"] =
      some (.andThen (.call "relay") (.call "mark")) := rfl
theorem map_relay_and_mark :
    mapCommand (.andThen (.call "relay") (.call "mark")) =
      some (.andThen (.call .relay) (.call .mark)) := rfl
theorem fixture_and :
    parseSupported "relay && mark" = some (.andThen (.call .relay) (.call .mark)) := by
  simp only [parseSupported, parseProgram, lex_relay_and_mark, parse_relay_and_mark_toks, map_relay_and_mark]
theorem lex_left_and_or :
    lexString "relay && mark || relay" =
      some [Token.ident "relay", Token.andAnd, Token.ident "mark", Token.orOr, Token.ident "relay"] := rfl
theorem parse_left_and_or_toks :
    parseTokens [Token.ident "relay", Token.andAnd, Token.ident "mark", Token.orOr, Token.ident "relay"] =
      some (.orElse (.andThen (.call "relay") (.call "mark")) (.call "relay")) := rfl
theorem fixture_left_and_or :
    parseSupported "relay && mark || relay" =
      some (.orElse (.andThen (.call .relay) (.call .mark)) (.call .relay)) := by
  have hm : mapCommand (.orElse (.andThen (.call "relay") (.call "mark")) (.call "relay")) =
      some (.orElse (.andThen (.call .relay) (.call .mark)) (.call .relay)) := rfl
  simp only [parseSupported, parseProgram, lex_left_and_or, parse_left_and_or_toks, hm]
theorem lex_paren :
    lexString "( relay || mark ) && relay" =
      some [Token.lParen, Token.ident "relay", Token.orOr, Token.ident "mark", Token.rParen,
            Token.andAnd, Token.ident "relay"] := rfl
theorem parse_paren_toks :
    parseTokens [Token.lParen, Token.ident "relay", Token.orOr, Token.ident "mark", Token.rParen,
                 Token.andAnd, Token.ident "relay"] =
      some (.andThen (.orElse (.call "relay") (.call "mark")) (.call "relay")) := rfl
theorem fixture_paren :
    parseSupported "( relay || mark ) && relay" =
      some (.andThen (.orElse (.call .relay) (.call .mark)) (.call .relay)) := by
  have hm : mapCommand (.andThen (.orElse (.call "relay") (.call "mark")) (.call "relay")) =
      some (.andThen (.orElse (.call .relay) (.call .mark)) (.call .relay)) := rfl
  simp only [parseSupported, parseProgram, lex_paren, parse_paren_toks, hm]
theorem grammar_and :
    AndorDerives [Token.ident "relay", Token.andAnd, Token.ident "mark"]
      (.andThen (.call "relay") (.call "mark")) :=
  AndorDerives.and (AndorDerives.single (.ident "relay")) (.ident "mark")
end CalculusShellText
