#!/usr/bin/env python3
"""PRIVATE supplemental 188 CalculusShellTextExport replay.

Does not edit shared artifact/manifest/replay.py. Not part of full-30.
Does not inherit oleans; no Lake fan-out. Direct Lean 4.31 serial under shared lock.
"""
from __future__ import annotations

import datetime
import json
import re
import shutil
import sys
import tempfile
import uuid
from pathlib import Path

JOB = Path(__file__).resolve().parent
ARCH = JOB / 'archive'
import hashlib
support = JOB / 'runner_support.py'
if hashlib.sha256(support.read_bytes()).hexdigest() != "67b0c574322212d990d40bfb7975c65c7642afdccf0df0e9cc2073543a4279ad":
    raise RuntimeError('frozen runner support hash mismatch')
from runner_support import (
    ALLOWED_AXIOMS, HOST_LEAN_ADDRESS_SPACE, LEAN_TOOLCHAIN,
    _parse_axiom_prints, _pinned_lean_binary, hash_verify_host, run_real, sha,
)

MODULES = [
    'CalculusNested', 'CalculusExport', 'CalculusBody', 'CalculusSimulation',
    'CalculusRelayLoop', 'CalculusRelayOuter', 'MemoryTransfer', 'BufferRelay',
    'CompareMain', 'CalculusRelaySpec', 'ScheduleConsumption', 'CalculusRelaySchedules',
    'CalculusRelayShared', 'ShellObservation', 'CalculusCommands', 'CalculusLowering',
    'CalculusShellText', 'CalculusShellTextSound', 'CalculusQuery',
    'CalculusQueryExportLink', 'CalculusShellTextQuery', 'CalculusShellTextRootFixtures',
    'CalculusShellTextExport',
]

AUDIT = {
    'CalculusShellTextExport': [
        'markSpec_of_lowering',
        'compileScriptQuery_nested_export',
        'compiled_program_export',
        'parse_relayAndMark',
        'parse_relayOrMark',
        'parse_paren_trailing',
        'reject_pipe',
        'text_relayAndMark_markedOrFailed_export',
        'text_relayOrMark_statusZero_export',
    ],
}

SOURCE_FILES = json.loads((JOB / 'CLOSURE.json').read_text())['files']
FROZEN_EXPORT = '8f08cf61c4f126e0b994a436f2fd7cf62dcee09b440e7268c15c454559a0c114'
LEAN = '/home/coder/.elan/toolchains/leanprover--lean4---v4.31.0/bin/lean'
SORRY_RE = re.compile(r'\bsorry\b')


def main() -> int:
    out_root = JOB / 'replay-out'
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    receipts = out_root / stamp
    receipts.mkdir(parents=True)
    result = dict(
        passed=False,
        id='lean_calculus_shelltextexport188_replay',
        supplemental=True,
        included_in_full30=False,
        per_file=[],
        axiom_results={},
        axiom_results_by_file={},
        stamp=stamp,
        source_to_calculus_C_link='OPEN181',
    )
    hashes = dict(SOURCE_FILES)
    ok, identity = hash_verify_host(ARCH, hashes)
    result['file_identity'] = identity
    if not ok:
        result['reason'] = 'archive identity mismatch'
        (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, indent=2))
        return 1
    if hashes['CalculusShellTextExport.lean'] != FROZEN_EXPORT:
        result['reason'] = 'frozen module175 source hash mismatch'
        (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
        return 1
    if (ARCH / 'lean-toolchain').read_text() != LEAN_TOOLCHAIN:
        result['reason'] = 'unexpected pinned Lean toolchain'
        (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
        return 1
    for module, expected in AUDIT.items():
        names = re.findall(r'^#print axioms (\S+)', (ARCH / (module + '.lean')).read_text(), re.M)
        if names != expected:
            result['reason'] = 'archive audit mismatch: ' + module
            result['audit_names'] = names
            (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
            return 1
    for lean_file in ARCH.glob('*.lean'):
        body = lean_file.read_text()
        stripped = re.sub(r'/-.*?-/', '', body, flags=re.S)
        stripped = re.sub(r'--.*', '', stripped)
        if SORRY_RE.search(stripped):
            result['reason'] = 'sorry present: ' + lean_file.name
            (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
            return 1
    lean = _pinned_lean_binary()
    if str(lean) != LEAN:
        result['reason'] = 'unexpected lean binary: ' + str(lean)
        (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
        return 1
    scratch = Path(tempfile.mkdtemp(prefix='shell188-' + uuid.uuid4().hex[:8] + '-'))
    for filename in hashes:
        shutil.copy2(ARCH / filename, scratch / filename)
    staged_ok, staged_identity = hash_verify_host(scratch, hashes)
    result.update(
        scratch_prefix='shell188-', scratch=str(scratch),
        staged_identity=staged_identity,
        compiler=str(lean),
        compiler_sha256=sha(lean),
    )
    if not staged_ok:
        result['reason'] = 'staged snapshot identity mismatch'
        (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
        return 1
    env = {'LEAN_PATH': str(scratch), 'LEAN_NUM_THREADS': '1', 'MIMALLOC_ARENA_RESERVE': '65536'}
    for module in MODULES:
        output = scratch / (module + '.olean')
        log = receipts / ('lean_calculus_shelltextexport188_replay.' + module + '.log')
        argv = [
            'timeout', '60', 'prlimit', f'--as={HOST_LEAN_ADDRESS_SPACE}', '--',
            str(lean), '-j1', '-s16384', '-DwarningAsError=true', '-DElab.async=false',
            '-o', str(output), module + '.lean',
        ]
        lock_attempts = []
        for lock_attempt in range(60):
            code, elapsed = run_real(argv, scratch, 60, log, max_wait=5, extra_env=env)
            if not (code is None and log.exists() and 'lock wait expired' in log.read_text()):
                break
            wait_log = log.with_name(log.name + '.lock-' + str(lock_attempt))
            shutil.copy2(log, wait_log)
            lock_attempts.append(dict(attempt=lock_attempt, log=wait_log.name, log_sha256=sha(wait_log)))
        if lock_attempts:
            result.setdefault('lock_only_retries', {})[module] = lock_attempts
        if code is None and log.exists() and 'lock wait expired' in log.read_text():
            result['reason'] = 'compiler lock busy'
            result['skipped'] = True
            (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
            print(json.dumps({'passed': False, 'reason': result['reason']}, indent=2))
            return 75
        log_text = log.read_text() if log.exists() else ''
        receipt = dict(
            file=module + '.lean', command=argv, workdir=str(scratch),
            environment={
                'LEAN_PATH': str(scratch),
                'LEAN_NUM_THREADS': '1',
                'MIMALLOC_ARENA_RESERVE': '65536',
            },
            address_space_bytes=HOST_LEAN_ADDRESS_SPACE, exit_status=code,
            elapsed_seconds=elapsed, log=str(log),
            log_sha256=sha(log) if log.exists() else None,
            output=str(output),
            output_sha256=sha(output) if output.is_file() else None,
            source_sha256=sha(scratch / (module + '.lean')),
        )
        if module == 'CalculusShellTextExport' and receipt['source_sha256'] != FROZEN_EXPORT:
            result['reason'] = 'export sourcehash mismatch vs frozen 175'
            (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
            return 1
        receipt_path = receipts / ('lean_calculus_shelltextexport188_replay.' + module + '.json')
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        result['per_file'].append({**receipt, 'receipt': receipt_path.name})
        if code != 0 or not output.is_file() or output.stat().st_size == 0:
            result['reason'] = 'compiler failure or missing output: ' + module
            (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
            print(json.dumps({'passed': False, 'reason': result['reason']}, indent=2))
            return 1
        if module in AUDIT:
            if not log_text.strip():
                result['reason'] = 'empty axiom log (no heuristic pass): ' + module
                (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
                return 1
            names, parsed = _parse_axiom_prints(log_text)
            expected = AUDIT[module]
            namespace = module
            qualified = [n if n.startswith(namespace + '.') else namespace + '.' + n for n in expected]
            result['axiom_results_by_file'][module] = dict(
                names=names, expected=expected, qualified=qualified, parsed=parsed)
            for name, info in parsed.items():
                result['axiom_results'][module + ':' + name] = info
            ok_names = names == expected or names == qualified
            if not ok_names or any(not parsed[n]['allowed'] for n in names):
                result['reason'] = 'audit mismatch or forbidden axiom: ' + module
                result['audit_names'] = names
                (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
                return 1
            if len(names) != 9:
                result['reason'] = 'expected 9 named axiom outputs'
                (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
                return 1
    expected_count = sum(len(v) for v in AUDIT.values())
    result['passed'] = (
        len(result['axiom_results']) == expected_count
        and set(result['axiom_results_by_file']) == set(AUDIT)
        and all(a['allowed'] for a in result['axiom_results'].values())
    )
    if not result['passed']:
        result['reason'] = result.get('reason') or 'audit key order/count mismatch'
    result['exit_status'] = 0 if result['passed'] else 1
    result['scope'] = (
        'Supplemental supported text/query connector using exported mark body. '
        'Not packaged into full-30.'
    )
    result['not_claimed'] = [
        'full-30 membership',
        'source-to-calculus C link (OPEN181)',
        'host Bash semantic equivalence',
        'query text parser',
        'grammar expansion',
        'OCaml/C source semantics',
    ]
    result['axiom_whitelist'] = sorted(ALLOWED_AXIOMS)
    (receipts / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('passed', 'exit_status', 'stamp') if k in result}, indent=2))
    print('receipts', receipts.name)
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
