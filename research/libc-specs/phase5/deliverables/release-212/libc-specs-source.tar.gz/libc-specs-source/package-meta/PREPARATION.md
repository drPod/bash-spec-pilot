# Source-package preparation (job 176, hardened in 178/182/202)

**Scope:** deterministic builder + inventory only. **Do not** produce the final release tarball
until root invokes `--build --release-ready` after:

- full30 replay **174** success (`exit.json` `exit_code=0` and one parseable `replay-out/*/summary.json`)
- independent supplemental replay **191** success (same terminal rule)
- independent Clight source replay **196** success (same terminal rule)
- paper/docs/catalog **final** requirements readiness as an **explicit root flag** (`--release-ready`);
  not an automatic goal claim. Pending 200 matrix / paper / catalog is not auto-complete.

**Constraints honored:** no git commits; no edits under the research repo; no compile; no
deletes of existing jobs; no publish/catalog/network; no secrets printed (secret-name skips
report **paths and count only**, never file contents).

## Layout

| Path | Role |
|---|---|
| `build_package.py` | inventory + optional deterministic tar |
| `SOURCE-SNAPSHOT.md` | packed as `package-meta/SOURCE-SNAPSHOT.md` |
| `PREPARATION.md` | this file (root review) |
| `inventory.json` | counts, notes, missing host tools (no file list) |
| `inventory.jsonl` | one JSON object per packed path + sha256 |

Default `--out-dir`: `/home/coder/agent-jobs/astra-research/phase5/deliverables`
(outside the repo and outside this job, so the builder does not pack itself).

## How root builds the release

```sh
python3 /home/coder/agent-jobs/astra-research/phase5/pi-reviews/source-package-prep-176/build_package.py \
  --build --release-ready --out-dir /home/coder/agent-jobs/astra-research/phase5/deliverables
```

Produces `libc-specs-source.tar.gz`, `libc-specs-source.tar.gz.sha256`, `BUILD-REPORT.json`.
Inner tar: **all members lexicographically sorted** (including `INVENTORY-*` / `SHA256SUMS`),
`mtime=uid=gid=0`, empty uname/gname, gzip `mtime=0`, file modes `0644` or `0755` if any
execute bit was set on the source. Packed `INVENTORY-HEAD.json` **omits `generated_utc`**
so wall-clock inventory timestamps do not change archive bytes.

`--build` **refuses** (exit 2, **does not write or delete** existing outputs) unless all of:

1. 174 successful terminal + unique parseable summary
2. 191 successful terminal + unique parseable summary
3. 196 successful terminal + unique parseable summary
4. `--release-ready` is passed by root (paper/docs/catalog final)

Atomic staging: tarball/report are assembled under a temp dir in `--out-dir` and
`os.replace`d only after `verify_tar` succeeds. Failed verification or exceptions after
staging **must not** unlink a pre-existing release. Root 182 already fixed terminal-refuse
non-deletion; 202 extends that to post-write verify failure via staging.

Inventory-only:

```sh
python3 build_package.py --inventory
```

## Allowlist (external)

Copied at **build** time from the live host. **None of 175/191/196 is a full30 entry.**

1. **Full replay 174** — `pi-reviews/root-artifact-full30-174/`  
   `process.json`, `manifest.snapshot.json`, `replay.snapshot.py`, entire `replay-out/`.  
   Bundle tag `full30-174`. This is the **only** full30 snapshot.

2. **Root reviews** — each `pi-reviews/root-*` directory, **only** the named review files
   (`ROOT-REVIEW.json`, `REPORT.md`, …). Includes **197** and **198** receipts when present.

3. **Independent auditor 177** — `AUDIT.json`, `REPORT.md`, `CHECKS.json`, `CHECKPOINT.md`.

4. **Audit 195** — `AUDIT.json`, `REPORT.md` only.

5. **Requirements 200** — eventual `REQUIREMENT-MATRIX.*` / `MATRIX.*` / `REQUIREMENTS.md` /
   `REPORT.md` / `AUDIT.json` when present. Absence is noted; not a completeness claim.

6. **Supplemental 175** — `check.sh`, `PROGRESS.md`, `project/` sources, `receipts/`.
   Packed under `external-receipts/supplemental-175-not-full30`. **Not full30.**

7. **Supplemental 191** (accepted 198) — frozen `archive/`, `CLOSURE.json`, `replay.py`,
   `runner_support.py`, `replay-out/` results, `PREPARATION.md`/`REPORT.md`.
   Packed under `external-receipts/supplemental-191-not-full30`. Freeze supports included.
   **Independent proof replay; not full30.**

8. **Source 196** (accepted 197) — 191 equivalents plus `freeze/` (generator + frozen
   inputs/receipts), `tests/fixtures/`, `tests/generator_fixtures.py`.
   Packed under `external-receipts/source-196-not-full30`. **Not full30.**
   `historical-cp17/` is **not** packed.

Not copied: other private jobs, `sessions/`, launchers, `events.jsonl`, credentials,
historical draft jobs, compiler receipts under `phase5/runs/`.

## Artifact-runner coverage

In-tree sources used by the runner (all under `research/libc-specs` if present) plus
independent 191/196 `replay.py` + `runner_support.py` + frozen archives so the portable
source artifact can replay those proofs without the private job trees.

**Needed outside the tree (not packed):** elan `leanprover--lean4---v4.31.0`, Docker
`phase5-vst`, compiler lock/scratch, `--out-dir` outside repo. Hash-pin paths for 191/196
closures live in packed `CLOSURE.json`; missing host binaries are listed in
`missing_needed_outside` (Lean/Lake/container), not as lost archive members.

## Exclusions

Caches/compiled, `.git`, secret **filenames** (count + paths only), `sessions/`,
`events.jsonl`, `historical-cp17`, symlinks whose targets resolve outside the walked root.

## Non-goals

Not a manuscript, not a catalog import, not a claim that the user goal is complete.
Do not treat 175/191/196 as part of full30. Do not build the real archive until root asks.
Do not auto-pass `--release-ready`.

## Root review 182 / 202

182: terminal gate requires `exit.json` `exit_code=0` and one parseable summary; refused
build preserves existing outputs.

202: same gate for 191 and 196; `--release-ready` required; atomic staging so verify
failure does not delete existing bytes; explicit 191/196/195/197/198/200 allowlists;
secret-name inventory reports filenames/count only.
