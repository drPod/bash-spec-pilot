# Source snapshot (libc-specs)

This file describes what a **content-hashed tar** of `research/libc-specs` is and is not.
Delivery is **not** a git commit.

## Untracked working tree vs Git

`research/libc-specs/` (~29 MB) is an **untracked working tree** in `bash-spec-pilot`.
`git ls-files` lists nothing under it. Frozen inputs and artifact sources must keep **byte identity**
(SHA-256 in `SHA256SUMS` / `INVENTORY.jsonl`). Do not “clean” or reformat files during packaging.

Git history of the parent repo does **not** pin this tree. Reproducible delivery is:

1. deterministic `libc-specs-source.tar.gz` (sorted members, `mtime/uid/gid` zero, gzip `mtime=0`);
2. sidecar `*.tar.gz.sha256`;
3. inner `SHA256SUMS` of every packed file.

## What is packed

- The whole `research/libc-specs` tree: phase 1–5 docs, Lean/Coq/C/OCaml sources, `phase5/artifact/`
  archives, results, tools (`replay.py`, `run_vst.py`, `check_experiments.py`, manifests).
- **Allowlisted** host receipts only (175/191/196 are **not** full30):
  - `external-receipts/root-artifact-full30-174/` — the only full30 snapshot.
  - `external-receipts/root-reviews/root-*/` — named review files only (includes 197/198).
  - independent 177/195 reports; eventual 200 requirement matrix if present.
  - `supplemental-175-not-full30`, `supplemental-191-not-full30` (frozen archive/CLOSURE/replay/runner_support/results),
    `source-196-not-full30` (same plus freeze/generator fixtures). No events/sessions/credentials/historical-cp17.

## What is excluded

- `.git`, credentials / `.env` / key material (names skipped; never printed).
- Caches and compiled outputs: `__pycache__`, `.lake`, `.olean`, `.vo`, `.glob`, object files, cores.
- Directory/file **symlinks that point outside** the walked root (not followed).
- Host Lean/Lake/Docker images, compiler lock, `~/.cache/bash-spec-pilot/*`, `phase5/runs/*`.

## Trusted tools / how to run the artifact

Pinned in-tree replay:

```sh
python3 research/libc-specs/phase5/artifact/replay.py --fresh --out-dir DIR_OUTSIDE_REPO
```

Earlier experiment replay (Lean models only):

```sh
uv run --no-project python research/libc-specs/check_experiments.py
```

**Host dependencies (not in the tarball):**

| Tool | Role |
|---|---|
| Lean 4.31.0 (`leanprover/lean4:v4.31.0` via elan) | required Lean entries; sequential `-j1` |
| `lake` from that toolchain | some Lake-staged entries |
| `gcc` | `c_relay_compile` |
| Docker container `phase5-vst` (1 CPU, 3 GiB) + `run_vst.py` | Coq/VST/OCaml **current** entries |
| `uv` / CPython 3 | drivers |

No model API credentials are required to replay compilers.

## Finite vs proof limits

A passing Lean kernel check covers the **accepted theorem’s quantified cases under its hypotheses**.
It is not a claim of full GNU Bash, complete libc, CompCert C frontend, or unbounded shell execution.

- Lean is total; shell loops are modeled with fuel / inductive relations, not as unrestricted
  total functions.
- Manifest `required` vs `current` vs `experimental` vs `pending` are distinct. `required_all_passed`
  is only the small required set. `full_scope_complete` is the full-manifest flag.
- Replay 174 is the intended full live receipt; packaging must copy that result, not invent PASS.
- Finite `#eval` / token / corpus comparisons are **not** the same as kernel theorems.

## Frozen bytes

Archives under `phase5/artifact/archive/*` and hashed sources in `manifest.json` must unpack to the
same SHA-256 as packed. The builder refuses to pack if bytes change mid-copy.
